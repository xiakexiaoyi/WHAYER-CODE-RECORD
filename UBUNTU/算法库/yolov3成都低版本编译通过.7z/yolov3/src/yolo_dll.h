#ifndef YOLO_DLL_H
#define YOLO_DLL_H


typedef struct {
	int		lWidth;				// Off-screen width
	int 	lHeight;			// Off-screen height
	int		lPixelArrayFormat;	// Format of pixel array
	union
	{
		struct
		{
			int lLineBytes;
			void *pPixel;
		} chunky;
		struct
		{
			int lLinebytesArray[4];
			void *pPixelArray[4];
		} planar;
	} pixelArray;
} YOLOV3_IMAGES, *YOLOV3_PIMAGES;

typedef struct
{
	int left;
	int top;
	int right;
	int bottom;
} YOLOV3RECT, *YOLOV3PRECT;

typedef struct
{
	int  flag;// 
	YOLOV3RECT    Target;///Ŀ��rectangle
	float dVal;  //Ŀ��value
	float dConfidence; //Ŀ��confidence
}HYYOLOV3_RESULT;///text read result

typedef struct
{
	HYYOLOV3_RESULT *pResult;
	int  lResultNum;   //����õ������Ŀ
}HYYOLOV3RESULT_LIST,*HYYOLOV3RESULT_PLIST;

//#define YOLODLL_API __declspec(dllexport) 
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllexport)
#else
#define YOLODLL_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef GPU
YOLODLL_API int init_gpu(void **handle, char *cfgfile, char *weightfile,float thresh,int gpu_index);
YOLODLL_API int uninit_gpu(void *handle);
YOLODLL_API int detec_gpu(void *handle, YOLOV3_PIMAGES img, HYYOLOV3RESULT_PLIST pResultList);
#else
YOLODLL_API int init_no_gpu(void **handle, char *cfgfile, char *weightfile, float thresh);
YOLODLL_API int uninit_no_gpu(void *handle);
YOLODLL_API int detec_no_gpu(void *handle, YOLOV3_PIMAGES img, HYYOLOV3RESULT_PLIST pResultList);
#endif

#ifdef __cplusplus
}
#endif




#endif
