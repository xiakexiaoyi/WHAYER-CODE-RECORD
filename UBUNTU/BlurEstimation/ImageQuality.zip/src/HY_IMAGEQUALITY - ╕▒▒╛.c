/*!
* \file HY_IMAGEQUALITY.C
* \brief  the API function
* \author hmy@whayer
* \version vision 1.0 
* \date 23 June 2014
*/

#include"HY_IMAGEQUALITY.h"
#include"lidebug.h"
#include "liblock.h"
#include "licomdef.h"
#include"litimer.h"
#include"liimage.h"
#include"liimgfmttrans.h"
#include"liedge.h"
#include"liconv.h"
#include"liimfilter.h"
#include"linoise.h"
#include"limatrix.h"
#include"LiErrFunc.h"
#include"ligaussian.h"
#include"liblur.h"
#include"limath.h"
#include"DFT.h"
#include"LiBright.h"
#include "lichannel.h"
#include"Lihist.h"
#include "FmttransYUV2BGR.h"
#include"LiFrmDif.h"


typedef struct  
{
    MHandle	hMemMgr;
    MLong patchsize;
    MFloat condf;
    MLong decim;
    MLong itr;
}IMQU,*PIMQU;


/// \brief _TransToInteriorImgFmt trans the out formation to the inner formation
/// \param PIMG the input img;

JOFFSCREEN _TransToInteriorImgFmt(const IQ_IMAGES* pImg)
{
    JOFFSCREEN img = *(JOFFSCREEN*)pImg;
    switch(img.fmtImg)
    {
        
    case HY_IMAGE_GRAY:
        img.fmtImg = FORMAT_GRAY;
        break;
    case HY_IMAGE_YUYV:
        img.fmtImg = FORMAT_YUYV;
        break;
    case HY_IMAGE_RGB:
        img.fmtImg = FORMAT_RGB;
        break;
    case HY_IMAGE_BGR:
        img.fmtImg = FORMAT_BGR;
        break;
    case HY_IMAGE_YUV420:
        img.fmtImg =FORMAT_YUV420;
        
#ifdef TRIM_RGB

#endif
    default:
        JASSERT(MFalse);
        break;
    }
    JASSERT(IF_DATA_BYTES(img.fmtImg) == 1);
    return img;
}


/// \brief TransGrayToBlock trans gray image to block
/// \param Image the source gray image
/// \param pBlockImg the block image
/// \return the error code

MVoid TransGrayImgToBlock(JOFFSCREEN Image,PBLOCK pBlockImg)
{
    pBlockImg->lBlockLine=Image.pixelArray.chunky.dwImgLine;
    pBlockImg->lHeight=Image.dwHeight;
    pBlockImg->lWidth=Image.dwWidth;
    pBlockImg->typeDataA=DATA_U8;
    pBlockImg->pBlockData=Image.pixelArray.chunky.pPixel;
}


/// \brief HYIQ_Init  Initial the memory
/// \param hMemMgr Handle
/// \param pIQreg the handle
/// \return the error code
MRESULT HYIQ_Init(MHandle hMemMgr,MHandle *pIQreg)
{
    MRESULT res=0;
    PIMQU PMIQ=MNull;
    AllocVectMem(hMemMgr,PMIQ,1,IMQU);
    SetVectMem(PMIQ,1,0,IMQU);
    PMIQ->hMemMgr=hMemMgr;
    *pIQreg=(MHandle)PMIQ;
    EXT:
    return res;	
}


/// \brief HYIQ_NOISE  Estimate the noise level
/// \param hMemMgr Handle
/// \param pImage the source image
/// \param pImage1 the source image 
/// \param ptOutParam output parameters 
/// \return the error code
MRESULT HYIQ_NOISE(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam)
{
    MRESULT res=LI_ERR_NONE;
    MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN ImgSrc  = _TransToInteriorImgFmt(pImage);
    JOFFSCREEN imgSrc1= _TransToInteriorImgFmt(pImage1);
    JOFFSCREEN Imggray={0};
    JOFFSCREEN imggray1={0};
    BLOCK blockimgsrc={0};
    BLOCK blockimgsrc1={0};
    MLong w,h,h1;
    BLOCKEXT blockimg1={0};
    BLOCKEXT blockplain={0};
    BLOCK blockgray1={0};
    BLOCK blockgray={0};
    MFloat NoiseL=0;
    JOFFSCREEN imgbgr={0};
    JOFFSCREEN imgbgr1={0};
	/// \judge if the input is empty or not
	if (pImqu == MNull )
	{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
    /// \if fmtimg=yuv420, transform to bgr
    /// \for single image ��Ӧ�ڵ���ͼ��
	///���ʻ����YUV420�źţ�����ת��ΪBGR�ź���������������Ҫ�����Ƶ���ź�
    if (imgSrc1.pixelArray.chunky.pPixel==MNull)
    {
        switch (ImgSrc.fmtImg)
        {
        case FORMAT_GRAY:
            TransGrayImgToBlock(ImgSrc,&blockimgsrc);
            break;
        case FORMAT_YUV420:
            GO( ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
            GO(FmttransYUV2BGR(&ImgSrc,&imgbgr));
            GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
            GO(ImgFmtTrans(&imgbgr,&Imggray));
            TransGrayImgToBlock(Imggray,&blockimgsrc);
			break;
		case FORMAT_RGB:
			GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
			GO(ImgFmtTrans(&ImgSrc,&Imggray));
            TransGrayImgToBlock(Imggray,&blockimgsrc);
         break;
        default:
       GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
       GO(ImgFmtTrans(&ImgSrc,&Imggray));
       TransGrayImgToBlock(Imggray,&blockimgsrc);
       break;       
        }
		///ɸѡ��ͼ��������߶�10%��������10%�����أ���Ϊ����osdӰ���б�
        w=blockimgsrc.lWidth;
        h=0.9*blockimgsrc.lHeight;
        h1=0.1*blockimgsrc.lHeight;
        blockimg1.block=blockimgsrc;
        blockimg1.ext.left=0;
        blockimg1.ext.right=blockimgsrc.lWidth;
        blockimg1.ext.top=h1;
        blockimg1.ext.bottom=h;
        blockplain.block=blockimgsrc;
        blockplain.ext.left=0;
        blockplain.ext.right=blockimgsrc.lWidth;
        blockplain.ext.top=h1;
        blockplain.ext.bottom=h;
		/// \choose a block to do the noise level estimate
		/// \ѡ����Ե��Ϣ���ٵ����飬1/16ȥ�б�����
        GO(SelePlainBlock(hMemMgr,&blockplain,&blockimg1));

        GO(NoiseLevel(hMemMgr,&NoiseL,&blockplain,7,0,0.99,3));///�����ɴ���matlab�汾����
    }

    /// \noise level estimate for videos
	/// ��֡����Ϣ�б���Ƶͼ�������
     if (imgSrc1.pixelArray.chunky.pPixel!=MNull)
     {
		 /// \format  transformation
         switch (ImgSrc.fmtImg)
         {
         case FORMAT_GRAY:
             TransGrayImgToBlock(ImgSrc,&blockimgsrc);
             break;
         case FORMAT_YUV420:
             GO( ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(FmttransYUV2BGR(&ImgSrc,&imgbgr)); 
            ///* PrintBmpEx(imgbgr.pixelArray.chunky.pPixel,imgbgr.pixelArray.chunky.dwImgLine,DATA_U8,imgbgr.dwWidth,imgbgr.dwHeight,3,"F:\\2.bmp");
             GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(ImgFmtTrans(&imgbgr,&Imggray));
            ////* PrintBmpEx(Imggray.pixelArray.chunky.pPixel,Imggray.pixelArray.chunky.dwImgLine,DATA_U8,Imggray.dwWidth,Imggray.dwHeight,1,"F:\\1.bmp");
             TransGrayImgToBlock(Imggray,&blockimgsrc);
             break;
		 case FORMAT_RGB:
			 GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
			 GO(ImgFmtTrans(&ImgSrc,&Imggray));
			 TransGrayImgToBlock(Imggray,&blockimgsrc);
			 break;
         default:
             GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(ImgFmtTrans(&ImgSrc,&Imggray));
             TransGrayImgToBlock(Imggray,&blockimgsrc);
         }
         switch (imgSrc1.fmtImg)
         {
         case FORMAT_GRAY:
             TransGrayImgToBlock(imgSrc1,&blockimgsrc1);
             break;
         case FORMAT_YUV420:
             GO( ImgCreate(hMemMgr,&imgbgr1,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(FmttransYUV2BGR(&imgSrc1,&imgbgr1));
             GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(ImgFmtTrans(&imgbgr1,&imggray1));
             TransGrayImgToBlock(imggray1,&blockimgsrc1);
             break;
		 case FORMAT_RGB:
			 GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
			 GO(ImgFmtTrans(&imgSrc1,&imggray1));
			 TransGrayImgToBlock(imggray1,&blockimgsrc1);
			 break;
         default:
             GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
             GO(ImgFmtTrans(&imgSrc1,&imggray1));
             TransGrayImgToBlock(imggray1,&blockimgsrc1);
         }
		 /// \noise level estimate for 2 images ��ǰ��֡ͼ���б���Ƶ����
         GO(NoiseLevelFrames(hMemMgr,&NoiseL,&blockimgsrc,&blockimgsrc1));
         
     }
     /// \output the noise level
	 /// ��������ȼ�
     ptOutParam->NOISELEVEL=NoiseL;
EXT:
     
     /// \release the memory�ͷ��ڴ�
         ImgRelease(hMemMgr,&Imggray);
         ImgRelease(hMemMgr,&imggray1);
         ImgRelease(hMemMgr,&imgbgr);
         ImgRelease(hMemMgr,&imgbgr1);

    return res;
}

/// \brief HYIQ_BLUR  Estimate the blur level
/// \param hMemMgr Handle
/// \param pImage the source image
/// \param pImage1 the source image 
/// \param ptOutParam output parameters 
/// \return the error code
MRESULT HYIQ_BLUR(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam)
{
    MRESULT res=LI_ERR_NONE;
    MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN ImgSrc  = _TransToInteriorImgFmt(pImage);
    JOFFSCREEN ImgSrc1={0};
    BLOCK BLOCKImage={0}; 
    BLOCK BLOCKImage1={0};
    BLOCKEXT blockimg1={0};
    BLOCKEXT blockplain={0};
    BLOCKEXT blocksel={0};
    BLOCKEXT blockedge={0};
    BLOCK edgemap={0};
    BLOCKEXT BlockP;
    MLong j,w,h,h1,i;
    MFloat NoiseL=0;
    MUInt8 *data2;
    MUInt8 *dataedge;
    MFloat sigma,sigma1,sigma2,sigma3;
    MLong a1,b1,a2,b2,a3,b3;
    BLOCK imga={0};
    BLOCK imgb={0};
    BLOCKEXT ImgA={0};
    BLOCKEXT ImgB={0};
    BLOCK blockp={0};
    MFloat eps=0.0000001;
    JOFFSCREEN imggray={0};
    JOFFSCREEN imggray2={0};
    JOFFSCREEN imgbgr={0};
    JOFFSCREEN imgbgr1={0};
	
	///�������ͼ��Ϊ�գ��򷵻ش���
	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	///������
	hMemMgr = pImqu->hMemMgr;

    /// \Initial the image format	 ��ͼ���ʽת��Ϊblock��ʽ�ĻҶ�ͼ
    switch(ImgSrc.fmtImg)
    {
    case FORMAT_GRAY:
        TransGrayImgToBlock(ImgSrc,&BLOCKImage);
        break;
    case FORMAT_YUV420:
        GO( ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
        GO(FmttransYUV2BGR(&ImgSrc,&imgbgr));
        GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
        GO(ImgFmtTrans(&imgbgr,&imggray));
        TransGrayImgToBlock(imggray,&BLOCKImage);
        break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(ImgFmtTrans(&ImgSrc,&imggray));
		TransGrayImgToBlock(imggray,&BLOCKImage);
		break;
    default:
        GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
        GO(ImgFmtTrans(&ImgSrc,&imggray));
        TransGrayImgToBlock(imggray,&BLOCKImage);
        break;       
    }
    

    /// \preprocessing :select the plain part of the image
	/// \ choose the 0.9height part of the image
	///Ԥ�������������������ϢΪ�գ�����㵥��ͼ������
	///ѡ���м�0.8*h��ͼ��
    w=BLOCKImage.lWidth;
    h=0.9*BLOCKImage.lHeight;
    h1=0.1*BLOCKImage.lHeight;
    blockimg1.block=BLOCKImage;
    blockimg1.ext.left=0;
    blockimg1.ext.right=BLOCKImage.lWidth;
    blockimg1.ext.top=h1;
    blockimg1.ext.bottom=h;
    blockplain.block=BLOCKImage;
    blockplain.ext.left=0;
    blockplain.ext.right=BLOCKImage.lWidth;
    blockplain.ext.top=h1;
    blockplain.ext.bottom=h;
	/// \choose a block to do the noise estimation
    GO(SelePlainBlock(hMemMgr,&blockplain,&blockimg1));

 /// \step1 noise level estimation �����ȼ�����
 /// \judge the noise level,if noise level is empty,then do the noise level estimate
  if (ptOutParam->NOISELEVEL<eps)
  {
      if(pImage1->pixelArray.chunky.pPixel==MNull)
    {
        GO(NoiseLevel(hMemMgr,&NoiseL,&blockplain,7,0,0.99,3));
 
    }
    if ((pImage1->pixelArray.chunky.pPixel!=MNull))
    {
        ImgSrc1  = _TransToInteriorImgFmt(pImage1);

        switch (ImgSrc1.fmtImg)
        {
        case FORMAT_GRAY:
            TransGrayImgToBlock(ImgSrc1,&BLOCKImage1);
            break;
        case FORMAT_YUV420:
            GO( ImgCreate(hMemMgr,&imgbgr1,FORMAT_BGR,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
            GO(FmttransYUV2BGR(&ImgSrc1,&imgbgr1));
            GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
            GO(ImgFmtTrans(&imgbgr1,&imggray2));
            TransGrayImgToBlock(imggray2,&BLOCKImage1);
		case FORMAT_RGB:
			GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
			GO(ImgFmtTrans(&ImgSrc1,&imggray2));
			TransGrayImgToBlock(imggray2,&BLOCKImage1);
			break;
            break;
        default:
            GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
            GO(ImgFmtTrans(&ImgSrc1,&imggray2));
            TransGrayImgToBlock(imggray2,&BLOCKImage1);
        }
        GO(NoiseLevelFrames(hMemMgr,&NoiseL,&BLOCKImage,&BLOCKImage1));
    }
  }
  /// \if noise level is not empty,use the noise level for further estimation
 if (ptOutParam->NOISELEVEL>eps)
  {
      NoiseL=ptOutParam->NOISELEVEL;
  }
   /// \step2 Improved canny method �ù�������������ȼ����canny��Ե

    GO(B_Create(hMemMgr,&edgemap,DATA_U8,blockimg1.block.lWidth,blockimg1.ext.bottom-blockimg1.ext.top));///��Եͼ��
    B_Set(&edgemap,0);
    data2=(MUInt8*)blockimg1.block.pBlockData+blockimg1.ext.left+(blockimg1.ext.top)*blockimg1.block.lBlockLine;
    dataedge=(MUInt8*)edgemap.pBlockData;
	///����������canny��Ե���
    GO(NoiseEdge(hMemMgr,data2,blockimg1.block.lBlockLine,(blockimg1.ext.right-blockimg1.ext.left),(blockimg1.ext.bottom-blockimg1.ext.top),dataedge,edgemap.lBlockLine,TYPE_CANNY,NoiseL));
	
    blockedge.ext.top=0;
    blockedge.ext.left=0;
    blockedge.ext.bottom=edgemap.lHeight;
    blockedge.ext.right=edgemap.lWidth;
    blockedge.block=edgemap;
 	//PrintBmpEx(dataedge,blockedge.block.lBlockLine,DATA_U8,blockedge.ext.right-blockedge.ext.left,blockedge.ext.bottom-blockedge.ext.top,1,"F:\\edge1.bmp");
    ///ѡ���Ե��Ϣǿ�ҵ�1/4����
	SeleBlock(hMemMgr,&blockimg1,&blockedge);
    data2=(MUInt8*)blockimg1.block.pBlockData+blockimg1.ext.left+(blockimg1.ext.top)*blockimg1.block.lBlockLine;
    dataedge=(MUInt8*)blockedge.block.pBlockData+blockedge.ext.left+(blockedge.ext.top)*(blockedge.block.lBlockLine);
   //PrintBmpEx(dataedge,blockedge.block.lBlockLine,DATA_U8,blockedge.ext.right-blockedge.ext.left,blockedge.ext.bottom-blockedge.ext.top,1,"F:\\edge.bmp");
   //PrintBmpEx(data2,blockimg1.block.lBlockLine,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top,1,"F:\\img.bmp");

    /// \step3 reblur the image 
	/// ��ģ��ͼ����sigma=1��sigma=2�Ĳ���ģ��ͼ����������������ʵ����
    /// \dealing with a1��b1
    a1=1;
    b1=2;
    GO(B_Create(hMemMgr,&imga,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
    GO(B_Create(hMemMgr,&imgb,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
    B_Set(&imga,0);
    B_Set(&imgb,0);
    ImgA.block=imga;
    ImgA.ext.left=0;
    ImgA.ext.right=imga.lWidth;
    ImgA.ext.top=0;
    ImgA.ext.bottom=imga.lHeight;
    ImgB.block=imgb;
    ImgB.ext.left=0;
    ImgB.ext.right=imgb.lWidth;
    ImgB.ext.top=0;
    ImgB.ext.bottom=imgb.lHeight;
	///��sigma=a1������ģ�����洢��imgA��
    GO(LiGaussianBlur(hMemMgr,&ImgA,&blockimg1,a1));
    //PrintBmpEx((MUInt8*)imga.pBlockData,imga.lBlockLine,DATA_U8,imga.lWidth,imga.lHeight,1,"c:\\imga.bmp");
	///��sigma=b1������ģ�����洢��imgB��
    GO(LiGaussianBlur(hMemMgr,&ImgB,&blockimg1,b1));
    GO(B_Create(hMemMgr,&blockp,DATA_F64,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
 //    PrintBmpEx((MUInt8*)imgb.pBlockData,imgb.lBlockLine,DATA_U8,imgb.lWidth,imgb.lHeight,1,"c:\\imgb.bmp");
    B_Set(&blockp,0);
    ImgA.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    ImgB.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    BlockP.block=blockp;
    BlockP.ext.left=0;
    BlockP.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    BlockP.ext.top=0;
    BlockP.ext.bottom=ImgA.ext.bottom;
	///��������ͼ��֮����ݶ����𣬸���matlab�㷨�ı�
    GO(LiBlur(hMemMgr,&BlockP,&blockimg1,&blockedge,&ImgA,&ImgB));
    ///��������ͼ����ݶ���Ϣ������sigmaa��sigmab���Ԥ��ͼ���sigma
	GO(Lisigma(hMemMgr,&sigma1,&BlockP,a1,b1));
 /// \dealing with a2��b2
	///���еڶ��ε���ģ��ͬ1
    a2=5;
    b2=7;
    B_Set(&imga,0);
    B_Set(&imgb,0);
    ImgA.block=imga;
    ImgA.ext.left=0;
    ImgA.ext.right=imga.lWidth;
    ImgA.ext.top=0;
    ImgA.ext.bottom=imga.lHeight;
    ImgB.block=imgb;
    ImgB.ext.left=0;
    ImgB.ext.right=imgb.lWidth;
    ImgB.ext.top=0;
    ImgB.ext.bottom=imgb.lHeight;
    GO(LiGaussianBlur(hMemMgr,&ImgA,&blockimg1,a2));
    GO(LiGaussianBlur(hMemMgr,&ImgB,&blockimg1,b2));
    B_Set(&blockp,0);
    ImgA.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    ImgB.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    BlockP.block=blockp;
    BlockP.ext.left=0;
    BlockP.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
    BlockP.ext.top=0;
    BlockP.ext.bottom=ImgA.ext.bottom;
    GO(LiBlur(hMemMgr,&BlockP,&blockimg1,&blockedge,&ImgA,&ImgB));
    GO(Lisigma(hMemMgr,&sigma2,&BlockP,a2,b2));
    ///����������ģ�����������sigmaֵ������ֵ���бȽϣ��õ�����sigma
    GO(SigmaSel(&sigma,sigma1,sigma2));


	///������
    ptOutParam->BLURLEVEL=sigma;
    ptOutParam->NOISELEVEL=NoiseL;
    ptOutParam->Sigma.sigma1=sigma1;
    ptOutParam->Sigma.sigma2=sigma2;
 

    
EXT:
    ///ɾ���ڴ�
    B_Release(hMemMgr,&edgemap);
    B_Release(hMemMgr,&imga);
    B_Release(hMemMgr,&imgb);
    B_Release(hMemMgr,&blockp);
    ImgRelease(hMemMgr,&imggray);
    ImgRelease(hMemMgr,&imggray2);
    ImgRelease(hMemMgr,&imgbgr);
    ImgRelease(hMemMgr,&imgbgr1);
    
    return res;
    
}



MRESULT HYIQ_COVERDUST(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam)
{
	MRESULT res=LI_ERR_NONE;
	MHandle hMemMgr = MNull;
	IMQU *pImqu = (IMQU *)hHandle;
	JOFFSCREEN ImgSrc  = _TransToInteriorImgFmt(pImage);
	JOFFSCREEN ImgSrc1={0};
	BLOCK BLOCKImage={0}; 
	BLOCK BLOCKImage1={0};
	BLOCKEXT blockimg1={0};
	BLOCKEXT blockplain={0};
	BLOCKEXT blocksel={0};
	BLOCKEXT blockedge={0};
	BLOCK edgemap={0};
	BLOCKEXT BlockP;
	MLong j,w,h,h1,i;
	MFloat NoiseL=0;
	MUInt8 *data2;
	MUInt8 *dataedge;
	MFloat sigma,sigma1,sigma2,sigma3;
	MLong a1,b1,a2,b2,a3,b3;
	BLOCK imga={0};
	BLOCK imgb={0};
	BLOCKEXT ImgA={0};
	BLOCKEXT ImgB={0};
	BLOCK blockp={0};
	MFloat eps=0.0000001;
	JOFFSCREEN imggray={0};
	JOFFSCREEN imggray2={0};
	JOFFSCREEN imgbgr={0};
	JOFFSCREEN imgbgr1={0};

	///�������ͼ��Ϊ�գ��򷵻ش���
	if (pImqu == MNull )
	{res = LI_ERR_UNKNOWN; goto EXT;}
	///������
	hMemMgr = pImqu->hMemMgr;

	/// \Initial the image format	 ��ͼ���ʽת��Ϊblock��ʽ�ĻҶ�ͼ
	switch(ImgSrc.fmtImg)
	{
	case FORMAT_GRAY:
		TransGrayImgToBlock(ImgSrc,&BLOCKImage);
		break;
	case FORMAT_YUV420:
		GO( ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(FmttransYUV2BGR(&ImgSrc,&imgbgr));
		GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(ImgFmtTrans(&imgbgr,&imggray));
		TransGrayImgToBlock(imggray,&BLOCKImage);
		break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(ImgFmtTrans(&ImgSrc,&imggray));
		TransGrayImgToBlock(imggray,&BLOCKImage);
		break;
	default:
		GO(ImgCreate(hMemMgr,&imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(ImgFmtTrans(&ImgSrc,&imggray));
		TransGrayImgToBlock(imggray,&BLOCKImage);
		break;       
	}


	/// \preprocessing :select the plain part of the image
	/// \ choose the 0.9height part of the image
	///Ԥ�������������������ϢΪ�գ�����㵥��ͼ������
	///ѡ���м�0.8*h��ͼ��
	w=BLOCKImage.lWidth;
	h=0.9*BLOCKImage.lHeight;
	h1=0.1*BLOCKImage.lHeight;
	blockimg1.block=BLOCKImage;
	blockimg1.ext.left=0;
	blockimg1.ext.right=BLOCKImage.lWidth;
	blockimg1.ext.top=h1;
	blockimg1.ext.bottom=h;
	blockplain.block=BLOCKImage;
	blockplain.ext.left=0;
	blockplain.ext.right=BLOCKImage.lWidth;
	blockplain.ext.top=h1;
	blockplain.ext.bottom=h;
	/// \choose a block to do the noise estimation
	GO(SelePlainBlock(hMemMgr,&blockplain,&blockimg1));

	/// \step1 noise level estimation �����ȼ�����
	/// \judge the noise level,if noise level is empty,then do the noise level estimate
	if (ptOutParam->NOISELEVEL<eps)
	{
		if(pImage1->pixelArray.chunky.pPixel==MNull)
		{
			GO(NoiseLevel(hMemMgr,&NoiseL,&blockplain,7,0,0.99,3));

		}
		if ((pImage1->pixelArray.chunky.pPixel!=MNull))
		{
			ImgSrc1  = _TransToInteriorImgFmt(pImage1);

			switch (ImgSrc1.fmtImg)
			{
			case FORMAT_GRAY:
				TransGrayImgToBlock(ImgSrc1,&BLOCKImage1);
				break;
			case FORMAT_YUV420:
				GO( ImgCreate(hMemMgr,&imgbgr1,FORMAT_BGR,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
				GO(FmttransYUV2BGR(&ImgSrc1,&imgbgr1));
				GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
				GO(ImgFmtTrans(&imgbgr1,&imggray2));
				TransGrayImgToBlock(imggray2,&BLOCKImage1);
			case FORMAT_RGB:
				GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
				GO(ImgFmtTrans(&ImgSrc1,&imggray2));
				TransGrayImgToBlock(imggray2,&BLOCKImage1);
				break;
				break;
			default:
				GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
				GO(ImgFmtTrans(&ImgSrc1,&imggray2));
				TransGrayImgToBlock(imggray2,&BLOCKImage1);
			}
			GO(NoiseLevelFrames(hMemMgr,&NoiseL,&BLOCKImage,&BLOCKImage1));
		}
	}
	/// \if noise level is not empty,use the noise level for further estimation
	if (ptOutParam->NOISELEVEL>eps)
	{
		NoiseL=ptOutParam->NOISELEVEL;
	}
	/// \step2 Improved canny method �ù�������������ȼ����canny��Ե

	GO(B_Create(hMemMgr,&edgemap,DATA_U8,blockimg1.block.lWidth,blockimg1.ext.bottom-blockimg1.ext.top));///��Եͼ��
	B_Set(&edgemap,0);
	data2=(MUInt8*)blockimg1.block.pBlockData+blockimg1.ext.left+(blockimg1.ext.top)*blockimg1.block.lBlockLine;
	dataedge=(MUInt8*)edgemap.pBlockData;
	///����������canny��Ե���
	GO(NoiseEdge(hMemMgr,data2,blockimg1.block.lBlockLine,(blockimg1.ext.right-blockimg1.ext.left),(blockimg1.ext.bottom-blockimg1.ext.top),dataedge,edgemap.lBlockLine,TYPE_CANNY,NoiseL));

	blockedge.ext.top=0;
	blockedge.ext.left=0;
	blockedge.ext.bottom=edgemap.lHeight;
	blockedge.ext.right=edgemap.lWidth;
	blockedge.block=edgemap;
	//PrintBmpEx(dataedge,blockedge.block.lBlockLine,DATA_U8,blockedge.ext.right-blockedge.ext.left,blockedge.ext.bottom-blockedge.ext.top,1,"F:\\edge1.bmp");
	///ѡ���Ե��Ϣǿ�ҵ�1/4����
	SeleBlock(hMemMgr,&blockimg1,&blockedge);
	data2=(MUInt8*)blockimg1.block.pBlockData+blockimg1.ext.left+(blockimg1.ext.top)*blockimg1.block.lBlockLine;
	dataedge=(MUInt8*)blockedge.block.pBlockData+blockedge.ext.left+(blockedge.ext.top)*(blockedge.block.lBlockLine);
	//PrintBmpEx(dataedge,blockedge.block.lBlockLine,DATA_U8,blockedge.ext.right-blockedge.ext.left,blockedge.ext.bottom-blockedge.ext.top,1,"F:\\edge.bmp");
	//PrintBmpEx(data2,blockimg1.block.lBlockLine,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top,1,"F:\\img.bmp");

	/// \step3 reblur the image 
	/// ��ģ��ͼ����sigma=1��sigma=2�Ĳ���ģ��ͼ����������������ʵ����
	/// \dealing with a1��b1
	a1=1;
	b1=2;
	GO(B_Create(hMemMgr,&imga,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
	GO(B_Create(hMemMgr,&imgb,DATA_U8,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
	B_Set(&imga,0);
	B_Set(&imgb,0);
	ImgA.block=imga;
	ImgA.ext.left=0;
	ImgA.ext.right=imga.lWidth;
	ImgA.ext.top=0;
	ImgA.ext.bottom=imga.lHeight;
	ImgB.block=imgb;
	ImgB.ext.left=0;
	ImgB.ext.right=imgb.lWidth;
	ImgB.ext.top=0;
	ImgB.ext.bottom=imgb.lHeight;
	///��sigma=a1������ģ�����洢��imgA��
	GO(LiGaussianBlur(hMemMgr,&ImgA,&blockimg1,a1));
	//PrintBmpEx((MUInt8*)imga.pBlockData,imga.lBlockLine,DATA_U8,imga.lWidth,imga.lHeight,1,"c:\\imga.bmp");
	///��sigma=b1������ģ�����洢��imgB��
	GO(LiGaussianBlur(hMemMgr,&ImgB,&blockimg1,b1));
	GO(B_Create(hMemMgr,&blockp,DATA_F64,blockimg1.ext.right-blockimg1.ext.left,blockimg1.ext.bottom-blockimg1.ext.top));
	//    PrintBmpEx((MUInt8*)imgb.pBlockData,imgb.lBlockLine,DATA_U8,imgb.lWidth,imgb.lHeight,1,"c:\\imgb.bmp");
	B_Set(&blockp,0);
	ImgA.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	ImgB.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	BlockP.block=blockp;
	BlockP.ext.left=0;
	BlockP.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	BlockP.ext.top=0;
	BlockP.ext.bottom=ImgA.ext.bottom;
	///��������ͼ��֮����ݶ����𣬸���matlab�㷨�ı�
	GO(LiBlur(hMemMgr,&BlockP,&blockimg1,&blockedge,&ImgA,&ImgB));
	///��������ͼ����ݶ���Ϣ������sigmaa��sigmab���Ԥ��ͼ���sigma
	GO(Lisigma(hMemMgr,&sigma1,&BlockP,a1,b1));
	/// \dealing with a2��b2
	///���еڶ��ε���ģ��ͬ1
	a2=5;
	b2=7;
	B_Set(&imga,0);
	B_Set(&imgb,0);
	ImgA.block=imga;
	ImgA.ext.left=0;
	ImgA.ext.right=imga.lWidth;
	ImgA.ext.top=0;
	ImgA.ext.bottom=imga.lHeight;
	ImgB.block=imgb;
	ImgB.ext.left=0;
	ImgB.ext.right=imgb.lWidth;
	ImgB.ext.top=0;
	ImgB.ext.bottom=imgb.lHeight;
	GO(LiGaussianBlur(hMemMgr,&ImgA,&blockimg1,a2));
	GO(LiGaussianBlur(hMemMgr,&ImgB,&blockimg1,b2));
	B_Set(&blockp,0);
	ImgA.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	ImgB.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	BlockP.block=blockp;
	BlockP.ext.left=0;
	BlockP.ext.right=MIN(ImgA.ext.right,ImgB.ext.right);
	BlockP.ext.top=0;
	BlockP.ext.bottom=ImgA.ext.bottom;
	GO(LiBlur(hMemMgr,&BlockP,&blockimg1,&blockedge,&ImgA,&ImgB));
	GO(Lisigma(hMemMgr,&sigma2,&BlockP,a2,b2));
	///����������ģ�����������sigmaֵ������ֵ���бȽϣ��õ�����sigma
	GO(SigmaSel(&sigma,sigma1,sigma2));

	///������
	ptOutParam->CoverDustLevel=sigma;
	ptOutParam->NOISELEVEL=NoiseL;
	ptOutParam->Sigma.sigma1=sigma1;
	ptOutParam->Sigma.sigma2=sigma2;

EXT:
	///ɾ���ڴ�
	B_Release(hMemMgr,&edgemap);
	B_Release(hMemMgr,&imga);
	B_Release(hMemMgr,&imgb);
	B_Release(hMemMgr,&blockp);
	ImgRelease(hMemMgr,&imggray);
	ImgRelease(hMemMgr,&imggray2);
	ImgRelease(hMemMgr,&imgbgr);
	ImgRelease(hMemMgr,&imgbgr1);

	return res;

}

//MRESULT HYIQ_COVERDUST(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam)
//{
//
//      //HYIQ_BLUR(hHandle,&pImage,&pImage1,&ptOutParam);
//	  //ptOutParam->BLURLEVEL
//	JOFFSCREEN imgsrc1;
//	IplImage* img_src;
//	IplImage *img_gray;
//	IplImage *subImg_gray;
//	double ratio=0.1;
//	int M=3;
//	int N=6;
//	int nDHeight;
//	int xStep;
//	int yStep;
//	double minValue=1000000;
//	double maxValue=0;
//	double minPixNum=0;
//	double contrastRatio=0;
//	float fHistValue;
//	CvRect rect;
//	CvHistogram* gray_hist;
//	int i,j,k;
//	int hist_size = 256;    //ֱ��ͼ�ߴ�  
//	float range[] = {0,255};  //�Ҷȼ��ķ�Χ  
//	float* ranges[]={range};  
//    
//     imgsrc1=_TransToInteriorImgFmt(pImage);
//	 nDHeight=imgsrc1.dwHeight*ratio;
//     xStep=imgsrc1.dwWidth/N;
//	 yStep=(imgsrc1.dwHeight-2*nDHeight)/M;
//	 minPixNum=xStep*yStep*0.003;
//     
//     subImg_gray=cvCreateImage(cvSize(xStep,yStep),IPL_DEPTH_8U,1);
//	 img_src= cvCreateImage(cvSize(imgsrc1.dwWidth,imgsrc1.dwHeight),IPL_DEPTH_8U,3);
//	 img_gray= cvCreateImage(cvSize(imgsrc1.dwWidth,imgsrc1.dwHeight),IPL_DEPTH_8U,1);
//	 img_src->imageData=imgsrc1.pixelArray.chunky.pPixel;
//	 cvCvtColor(img_src,img_gray,CV_BGR2GRAY);  
//	 cvNamedWindow("img",1);
//	 cvShowImage("img",img_src);
//	 cvWaitKey(0);
//
//	 //����һάֱ��ͼ��ͳ��ͼ����[0 255]���صľ��ȷֲ�  
//	 gray_hist = cvCreateHist(1,&hist_size,CV_HIST_ARRAY,ranges,1);  
//
//	 rect.width=xStep;
//	 rect.height=yStep;
//	 for (i=0;i<M;i++)
//	 {
//		 for (j=0;j<N;j++)
//			{
//                rect.x=j*xStep;
//				rect.y=nDHeight+i*yStep;
//				//��ͼ������ȡ��ͼ��
//				cvSetImageROI(img_gray, rect);
//				cvCopy(img_gray, subImg_gray,NULL);
//				cvResetImageROI(img_gray);
//				//����Ҷ�ͼ���һάֱ��ͼ  
//				cvCalcHist(&subImg_gray,gray_hist,0,0);
//
//				for (k=0;k<255;k++)
//				{
//                    fHistValue = cvQueryHistValue_1D(gray_hist, k); //����Ϊi��ֱ�����С
//					if (fHistValue>minPixNum)
//					{
//						//cout<<hist.at<float>(k,0)<<endl;
//						minValue=k;
//						break;
//					}
//				}
//
//				for (k=254;k>=0;k--)
//				{
//					fHistValue = cvQueryHistValue_1D(gray_hist, k); //����Ϊi��ֱ�����С
//					if (fHistValue>minPixNum)
//					{
//						//cout<<hist.at<float>(k,0)<<endl;
//						maxValue=k;
//						break;
//					}
//				}
//
//				contrastRatio=contrastRatio+(maxValue-minValue)/maxValue;
//	    	 }
//	 }
//	 contrastRatio=contrastRatio/(M*N);
//     
//	 cvReleaseImage(&img_gray);
//	 cvReleaseImage(&img_src);
//	 cvReleaseImage(&subImg_gray);
//	 cvReleaseHist(&gray_hist);
//	 return LI_ERR_UNKNOWN;
//
//}
/// \brief HYIQ_BRIGHT  check whether the bright is abnormal
/// \param hMemMgr Handle
/// \param pImage the source image
/// \param ptOutParam output parameters 
/// \return the error code

/// ����ͼ�����Ⱦ�ֵ��128֮��Ĳ���б��Ƿ���������쳣
MRESULT HYIQ_BRIGHT(MHandle hHandle,IQ_PIMAGES pImage, IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam)
{
	MHandle hMemMgr = MNull;
	IMQU *pImqu = (IMQU *)hHandle;
    MRESULT res=LI_ERR_NONE;
    JOFFSCREEN ImgSrc  = _TransToInteriorImgFmt(pImage);
    JOFFSCREEN ImgSrc1=_TransToInteriorImgFmt(pImage1);
    MFloat k,k1;
    MLong i,j;
    MLong ext;
    MUInt8 *data;
    MLong sum=0;
    MFloat mean=0.0;
    MLong len=ImgSrc.dwHeight*ImgSrc.dwWidth;
    JOFFSCREEN Imggray={0};
    JOFFSCREEN Imgbgr={0};
    JOFFSCREEN Imgbgr1={0};
    JOFFSCREEN Imggray1={0};
    MFloat temp=0;

	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
	///��ͼ��ת���Ҷ�ͼ��
    switch(ImgSrc.fmtImg)
    {
    case  FORMAT_YUV420:
            GO(ImgCreate(hMemMgr,&Imgbgr,FORMAT_BGR,ImgSrc.dwWidth,ImgSrc.dwHeight));
            FmttransYUV2BGR(&ImgSrc,&Imgbgr);
            GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
            GO(ImgFmtTrans(&Imgbgr,&Imggray));
            break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
		GO(ImgFmtTrans(&ImgSrc,&Imggray));
		break;
    default:
        GO(ImgCreate(hMemMgr,&Imggray,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
        GO(ImgFmtTrans(&ImgSrc,&Imggray));
    }
	///����ͼ��1������
    data=(MUInt8*)Imggray.pixelArray.chunky.pPixel;
    ext=Imggray.pixelArray.chunky.dwImgLine-Imggray.dwWidth;
    for(i=0;i<Imggray.dwHeight;i++,data+=ext)
    for(j=0;j<Imggray.dwWidth;j++,data++)
    {
        sum+=*(data);
    }
    mean=(float)sum/len;
    k=(mean-128)/128;
    ptOutParam->Bright.BrightLevel1=k;
	///����ͼ��2������
    switch(ImgSrc1.fmtImg)
    {
    case  FORMAT_YUV420:
        GO(ImgCreate(hMemMgr,&Imgbgr1,FORMAT_BGR,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
        FmttransYUV2BGR(&ImgSrc1,&Imgbgr1);
        GO(ImgCreate(hMemMgr,&Imggray1,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
        GO(ImgFmtTrans(&Imgbgr1,&Imggray1));
        break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&Imggray1,FORMAT_GRAY,ImgSrc1.dwWidth,ImgSrc1.dwHeight));
		GO(ImgFmtTrans(&ImgSrc1,&Imggray1));
		break;
    default:
        GO(ImgCreate(hMemMgr,&Imggray1,FORMAT_GRAY,ImgSrc.dwWidth,ImgSrc.dwHeight));
        GO(ImgFmtTrans(&ImgSrc1,&Imggray1));
    }
    sum=0;
    data=(MUInt8*)Imggray1.pixelArray.chunky.pPixel;
    ext=Imggray1.pixelArray.chunky.dwImgLine-Imggray1.dwWidth;
    for(i=0;i<Imggray1.dwHeight;i++,data+=ext)
        for(j=0;j<Imggray1.dwWidth;j++,data++)
        {
            sum+=*(data);
        }
        mean=(float)sum/len;
        k1=(mean-128)/128;
		///��֡ͼ��֮������Ȳ�����ں����ж�
        temp=fabs((k-k1)/k);
        ptOutParam->Bright.BrightLevel2=k1;
        ptOutParam->Bright.Brightderiv=temp;
		
EXT:
    ImgRelease(hMemMgr,&Imggray);
    ImgRelease(hMemMgr,&Imgbgr);
    ImgRelease(hMemMgr,&Imggray1);
    ImgRelease(hMemMgr,&Imgbgr1);
    return res;
}

/// \brief HYIQ_CAST  check whether the image is cast
/// \param hMemMgr Handle
/// \param pImage the source image
/// \param ptOutParam output parameters 
/// \return the error code
MRESULT HYIQ_CAST(MHandle hHandle,IQ_PIMAGES pImage, HYIQ_PTOutParam ptOutParam)
{

    MRESULT res=LI_ERR_NONE;
    MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN imgsrc=_TransToInteriorImgFmt(pImage);
    JOFFSCREEN imgrgb={0};
    MLong len=imgsrc.dwHeight*imgsrc.dwWidth;
    Ratio ratiosrc={0};
    
	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
   GO(ImgCreate(hMemMgr,&imgrgb,FORMAT_BGR,imgsrc.dwWidth,imgsrc.dwHeight));
   ///�б������ͼ���Ƿ���bgrͼ��
   switch (imgsrc.fmtImg)
   {
    case FORMAT_GRAY:
        res=LI_ERR_DATA_UNSUPPORT;
        return res;
    case FORMAT_YUV420:
       FmttransYUV2BGR(&imgsrc,&imgrgb);
	   break;
	case FORMAT_RGB:
		GO(ImgFmtTrans(&imgsrc,&imgrgb));
	   break;
    default:
         GO(ImgFmtTrans(&imgsrc,&imgrgb));
   }
   ///������ͨ������ɫƫ��
    GO(LiCast(hMemMgr,&imgrgb,&ratiosrc));
	///������ͨ������ɫƫ���б��Ƿ���ƫɫ��0.35����ʵ�����ݵó���
    if (ratiosrc.rratio>0.35||ratiosrc.gratio>0.35||ratiosrc.bratio>0.35)
    {
		ptOutParam->ImgCast.flag=1;///ƫɫ
	}
	else if(ratiosrc.bdev>0.5||ratiosrc.gdev>0.5||ratiosrc.rdev>0.5)
	{
         ptOutParam->ImgCast.flag=1;///ƫɫ
	}
	

    else
    {
        ptOutParam->ImgCast.flag=0;///����
    }
   
   ptOutParam->ImgCast.Bcastratio=ratiosrc.bratio;
   ptOutParam->ImgCast.Rcastratio=ratiosrc.rratio;
   ptOutParam->ImgCast.Gcastratio=ratiosrc.gratio;
  
    
EXT:

    ImgRelease(hMemMgr,&imgrgb);
    return res;
}



/// \brief HYIQ_Enhance  enhance the source image
/// \param hMemMgr Handle
/// \param pImage the source image
/// \param pImageres the enhanced image
/// \return the error code
/// ����ͼ���������ǿ
MRESULT HYIQ_ENHANCE(MHandle hHandle,IQ_PIMAGES pImagesrc,IQ_PIMAGES pImageres)
{
    MLong res=LI_ERR_NONE;
    MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN imgsrc=_TransToInteriorImgFmt(pImagesrc);
    JOFFSCREEN imgbgr={0};
    JOFFSCREEN imgres={0};
     
	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
    GO(ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,imgsrc.dwWidth,imgsrc.dwHeight));
    GO(ImgCreate(hMemMgr,&imgres,FORMAT_BGR,imgsrc.dwWidth,imgsrc.dwHeight));
     if(imgsrc.fmtImg==FORMAT_GRAY)
     {
         res=LI_ERR_DATA_UNSUPPORT;
         return res;
     }
	 ///ת��BGR��ʽ����ֱ��ͼ��ǿ
     GO(ImgFmtTrans(&imgsrc,&imgbgr));
	 ///ֱ��ͼ��ǿ
     GO(liEnhance(hMemMgr,&imgbgr,&imgres));
     pImageres->lHeight=imgres.dwHeight;
     pImageres->lWidth=imgres.dwWidth;
     pImageres->pixelArray.chunky.lLineBytes=imgres.pixelArray.chunky.dwImgLine;
     pImageres->pixelArray.chunky.pPixel=imgres.pixelArray.chunky.pPixel;
     switch(imgres.fmtImg)
     {
     case FORMAT_YUYV:
         pImageres->lPixelArrayFormat=HY_IMAGE_YUYV;
         break;
     case FORMAT_BGR:
        pImageres->lPixelArrayFormat=HY_IMAGE_BGR;
         break;
     case FORMAT_RGB:
         pImageres->lPixelArrayFormat=HY_IMAGE_RGB;
         break;
     
     default:
        JASSERT(MFalse);
        break;
     }

EXT:
     ImgRelease(hMemMgr,&imgbgr);

     return res;
}

/// \brief HYIQ_SaveImage
/// \param hMemMgr H
/// \param pImage the source image
/// \�洢ͼ��
MRESULT HYIQ_SaveImage(MHandle hHandle,IQ_PIMAGES pImagesrc,const char* filename)
{
    MLong res=LI_ERR_NONE;
    MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN imgsrc=_TransToInteriorImgFmt(pImagesrc);
    JOFFSCREEN imgbgr={0};
	
	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
    switch(imgsrc.fmtImg)
    {
     
    case FORMAT_YUV420:
        GO(ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,imgsrc.dwWidth,imgsrc.dwHeight));
        GO(FmttransYUV2BGR(&imgsrc,&imgbgr));
        PrintBmpEx((MUInt8*)imgbgr.pixelArray.chunky.pPixel,imgbgr.pixelArray.chunky.dwImgLine,DATA_U8,imgbgr.dwWidth,imgbgr.dwHeight,3,filename);
        break;
    case FORMAT_GRAY:
        PrintBmpEx((MUInt8*)imgsrc.pixelArray.chunky.pPixel,imgsrc.pixelArray.chunky.dwImgLine,DATA_U8,imgsrc.dwWidth,imgsrc.dwHeight,1,filename);
        break;
    default:
          GO(ImgCreate(hMemMgr,&imgbgr,FORMAT_BGR,imgsrc.dwWidth,imgsrc.dwHeight));
          GO(ImgFmtTrans(&imgsrc,&imgbgr));
          PrintBmpEx((MUInt8*)imgbgr.pixelArray.chunky.pPixel,imgbgr.pixelArray.chunky.dwImgLine,DATA_U8,imgbgr.dwWidth,imgbgr.dwHeight,3,filename);
    }

EXT:
    ImgRelease(hMemMgr,&imgbgr);
    return res;
}
///  ����֡���б��źŶ�ʧ���ǻ��涳��
MRESULT HYIQ_LOST(MHandle hHandle,IQ_PIMAGES pImagesrc1,IQ_PIMAGES pImagesrc2,HYIQ_PTOutParam ptOutParam)
{
    MLong res=LI_ERR_NONE;
	MHandle hMemMgr = MNull;
    IMQU *pImqu = (IMQU *)hHandle;
    JOFFSCREEN imgsrc1=_TransToInteriorImgFmt(pImagesrc1);
    JOFFSCREEN imgsrc2=_TransToInteriorImgFmt(pImagesrc2);
    JOFFSCREEN imgbgr1={0};
    JOFFSCREEN imgbgr2={0};
    JOFFSCREEN imggray1={0};
    JOFFSCREEN imggray2={0};
    JOFFSCREEN imgedge={0};
    MUInt8* psrc=MNull;
    MUInt8 *pedge=MNull;
    MFloat diff=0.0;
    MLong n=0;
    MLong i,j;
    MLong ext=0;
    MFloat ratio=0.0;
	MLong H[256];
	MLong num=imgsrc1.dwHeight*imgsrc1.dwWidth;
	MLong tmp=0;
	MLong Hmax=0;
	MFloat Hration=0.0;
	
	for(i=0;i<256;i++)
	{
		H[i]=0;
	}
	if (pImqu == MNull )
		{res = LI_ERR_UNKNOWN; goto EXT;}
	hMemMgr = pImqu->hMemMgr;
    switch(imgsrc1.fmtImg)
    {
    case FORMAT_YUV420:
        GO(ImgCreate(hMemMgr,&imgbgr1,FORMAT_BGR,imgsrc1.dwWidth,imgsrc1.dwHeight));
        GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,imgsrc1.dwWidth,imgsrc1.dwHeight));
        GO(FmttransYUV2BGR(&imgsrc1,&imgbgr1));
        GO(ImgFmtTrans(&imgbgr1,&imggray1));
        break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,imgsrc1.dwWidth,imgsrc1.dwHeight));
		GO(ImgFmtTrans(&imgsrc1,&imggray1));
		break;
    default:
        GO(ImgCreate(hMemMgr,&imggray1,FORMAT_GRAY,imgsrc1.dwWidth,imgsrc1.dwHeight));
        ImgFmtTrans(&imgsrc1,&imggray1);
    }
    switch(imgsrc2.fmtImg)
    {
    case FORMAT_YUV420:
        GO(ImgCreate(hMemMgr,&imgbgr2,FORMAT_BGR,imgsrc2.dwWidth,imgsrc2.dwHeight));
        GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,imgsrc2.dwWidth,imgsrc2.dwHeight));
        GO(FmttransYUV2BGR(&imgsrc2,&imgbgr2));
        GO(ImgFmtTrans(&imgbgr2,&imggray2));
        break;
	case FORMAT_RGB:
		GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,imgsrc2.dwWidth,imgsrc2.dwHeight));
		GO(ImgFmtTrans(&imgsrc2,&imggray2));
		
		break;
    default:
        GO(ImgCreate(hMemMgr,&imggray2,FORMAT_GRAY,imgsrc2.dwWidth,imgsrc2.dwHeight));
        ImgFmtTrans(&imgsrc2,&imggray2);
    }

/// \ judge the frames difference��������֡ͼ���֡��
    GO(LiFrmDif(&imggray1,&imggray2,&diff));
/// \judge for the gradient�������֡ͼ��Ĳ�𲻴������ͼ��ı�Ե��Ϣ�������źŶ�ʧ���ǻ��涳��
    psrc=(MUInt8*)imggray1.pixelArray.chunky.pPixel;
    GO(ImgCreate(hMemMgr,&imgedge,FORMAT_GRAY,imggray1.dwWidth,imggray1.dwHeight));
    pedge=(MUInt8*)imgedge.pixelArray.chunky.pPixel;
	ext=imggray1.pixelArray.chunky.dwImgLine-imggray1.dwWidth;
//	printf("the similarity is =%f",diff);
    if(diff>0.92) //��ֵ����ʵ���ã�������֡ͼ������ƶ�
    {
		///����ֱ��ͼ��ֵ����
		for(i=0;i<imggray1.dwHeight;i++,psrc+=ext)
		for(j=0;j<imggray1.dwWidth;j++,psrc++)
		{
			tmp=*psrc;
			H[tmp]=H[tmp]+1;
		}
		for(i=0;i<256;i++)
		{
			//printf("%d",H[i]);
			if(H[i]>Hmax)
			{
				Hmax=H[i];
			}
		}
		Hration=(MFloat)Hmax/num;

		///������ƶȴ����б���ı�Ե��Ϣ
        Edge(hMemMgr,psrc,imggray1.pixelArray.chunky.dwImgLine,imggray1.dwWidth,imggray1.dwHeight,pedge,imgedge.pixelArray.chunky.dwImgLine,TYPE_CANNY);
        pedge=(MUInt8*)imgedge.pixelArray.chunky.pPixel;
       // PrintBmpEx(pedge,imgedge.pixelArray.chunky.dwImgLine,DATA_U8,imgedge.dwWidth,imgedge.dwHeight,1,"f:\\test.bmp");
        ext=imgedge.pixelArray.chunky.dwImgLine-imgedge.dwWidth;
        for(i=0;i<imgedge.dwHeight;i++,pedge+=ext)
        for(j=0;j<imgedge.dwWidth;j++,pedge++)
        {
            if(*(pedge)==0) ///EDGE=0,��Ե
            n=n+1;
        }
        ratio=(MFloat)n/(imgedge.dwWidth*imgedge.dwHeight);
        if(diff>0.98&&ratio>0.025) //��ֵʵ����
            ptOutParam->Signal.flag=2;///���涳��
		if(diff>0.98&&Hration<0.7)
			ptOutParam->Signal.flag=2;///���涳��
        if(Hration>0.7)
            ptOutParam->Signal.flag=1; ///�źŶ�ʧ
    }

    
EXT:
    ImgRelease(hMemMgr,&imgbgr1);
    ImgRelease(hMemMgr,&imgbgr2);
    ImgRelease(hMemMgr,&imggray1);
    ImgRelease(hMemMgr,&imggray2);
    ImgRelease(hMemMgr,&imgedge);
    return res;
}


///\brief HYIQ_RESYLT show the result
///�б��û��Ƿ������б���ֵ������û�û�����룬��ʹ��Ĭ��ֵ������û������ˣ�������û����õ�ֵ
MRESULT HYIQ_RESULT(MHandle hHandle,HYIQ_PTOutParam ptOutParam,PCustomParam customp,pHYIQ_result result)
{
	MRESULT res=LI_ERR_NONE;
   IMQU *pImqu = (IMQU *)hHandle;
   MHandle hMemMgr=MNull;
   MFloat eps=0.0000001;
   if (pImqu == MNull )
   {res = LI_ERR_UNKNOWN; goto EXT;}
   hMemMgr = pImqu->hMemMgr;
  /* ģ�����ֵ���ֵ�Ǹ���matlab������ͼ�����Ӳ�ͬsigma�ĸ�˹ģ��֮���õġ����ģ����ʾͼ��������ģ������Ӱ��ͼ��ʵ������,�ж�ģ����ʾͼ���д��ڽ�
   Ϊ���Ե�ģ��������ͼ��������Ӱ�죬�ض�ģ����ʾͼ���������ģ����ͼ������������Ӱ���޷���ʶ*/
   if (customp->Blurlevel.BlurLevellowthresh==MNull)
   {
	   customp->Blurlevel.BlurLevellowthresh=2;//2.5
   }
   if(customp->Blurlevel.Blurlevelhighthresh==MNull)
   {
	   customp->Blurlevel.Blurlevelhighthresh=5;
   }
   if(customp->Blurlevel.Blurlevelhighthresh1==MNull)
   {
	   customp->Blurlevel.Blurlevelhighthresh1=20;
   }
/* �������ֵ���ֵ�Ǹ���matlab������ͼ�����Ӳ�ͬsigma�ĸ�˹����֮���õġ��Ͷ�������ָ�������������������Ĵ��ڲ�Ӱ��ʵ��ͼ������
�ж������ȼ���ָ���������������ҽ�Ϊ���ԡ��ض������ȼ���ָ���������������ҽ�Ϊ���ԣ���Ժ����������Ӱ�졣*/
   if (customp->Noiselevel.NoiseLevellowthresh==MNull)
   {
	   customp->Noiselevel.NoiseLevellowthresh=3;
   }
   if(customp->Noiselevel.Noiselevelhighthresh==MNull)
   {
	   customp->Noiselevel.Noiselevelhighthresh=5;
   }
   if(customp->Noiselevel.Noiselevelhighthresh1==MNull)
   {
	   customp->Noiselevel.Noiselevelhighthresh1=20;
   }
   if((customp->castratio-eps)<0)
   {
	   customp->castratio=0.35;
   }
   /*���Ȳ��ֵ���ֵ�Ǹ���ʵ�����ݲ������á����ڹ�����ֵ����ͼ�������С�ڹ�����ֵ�����ͼ�����*/
   if((customp->Light.darkthresh-eps)<0)
   {
	   customp->Light.darkthresh=-0.5;
   }
   if((customp->Light.lightthresh-eps)<0)
   {
	   customp->Light.lightthresh=0.5;
   }

   if (customp->CoverDustThreshold==MNull)
   {
	   customp->CoverDustThreshold=0.9;
   }

   //judge the image status
   /// ��ʵ��ֵ����ֵ���бȽϣ����ʵ�ʵ��ж�
   if(ptOutParam->BLURLEVEL<customp->Blurlevel.BlurLevellowthresh)
   {
	   result->blurstatus=IMAGE_UNBLUR; /*ͼ��ģ��*/
   }
   if((ptOutParam->BLURLEVEL>customp->Blurlevel.BlurLevellowthresh)&&(ptOutParam->BLURLEVEL<customp->Blurlevel.Blurlevelhighthresh))
   {
	   result->blurstatus=IMAGE_TINYBLUR;  /*ͼ�����ģ��*/
   }
   if((ptOutParam->BLURLEVEL>customp->Blurlevel.Blurlevelhighthresh)&&(ptOutParam->BLURLEVEL<customp->Blurlevel.Blurlevelhighthresh1))
   {
	   result->blurstatus=IMAGE_MEDBLUR;  /*ͼ���ж�ģ��*/
   }
   if(ptOutParam->BLURLEVEL>customp->Blurlevel.Blurlevelhighthresh1)
   {
	   result->blurstatus=IMAGE_HEVBLUR; /*ͼ���ض�ı��*/
   }
   if(ptOutParam->ImgCast.flag==1)
   {
	   result->caststatus=IMAGE_CAST;      /*ͼ��ƫɫ*/
   }
   if(ptOutParam->Bright.BrightLevel1>customp->Light.lightthresh)
   {
	   result->lightstatus=IMAGE_TOOLIGHT;  /*ͼ�����*/
   }
   if(ptOutParam->Bright.BrightLevel1<customp->Light.darkthresh)
   {
	   result->lightstatus=IMAGE_TOODARK;   /*ͼ�����*/
   }
   if(ptOutParam->NOISELEVEL<customp->Noiselevel.NoiseLevellowthresh)
   {
	   result->Noisestatus=IMAGE_UNNOISE;   /*ͼ�񲻴�������*/
   }
   if((ptOutParam->NOISELEVEL>customp->Noiselevel.NoiseLevellowthresh)&&(ptOutParam->NOISELEVEL<customp->Noiselevel.Noiselevelhighthresh))
   {
	   result->Noisestatus=IMAGE_TINYNOISE;  /*ͼ������������*/
   }
   if((ptOutParam->NOISELEVEL>customp->Noiselevel.Noiselevelhighthresh)&&(ptOutParam->NOISELEVEL<customp->Noiselevel.Noiselevelhighthresh1))
   {
	   result->Noisestatus=IMAGE_MEDNOISE;   /*ͼ������ж�����*/
   }
   if(ptOutParam->NOISELEVEL>customp->Noiselevel.Noiselevelhighthresh1)
   {
	   result->Noisestatus=IMAGE_HEAVENOISE; /*ͼ������ض�����*/
   }
   if (ptOutParam->Signal.flag==1)
   {
	   result->signalstatus=IMAGE_SIGNALLOST; /*�źŶ�ʧ*/
   }
   if(ptOutParam->Signal.flag==2)
   {
	   result->signalstatus=IMAGE_FROZEN;     /*���涳��*/
   }
   if (ptOutParam->CoverDustLevel>=customp->CoverDustThreshold)
   {
	   result->coverDuststatus=IMAGE_COVERDUST;
   } 
   //else
   //{
   //}
EXT:
   return res;

}
/// \brief HYIQ_Uninit  free the memory
/// \param hMemMgr Handle to be free
/// \return the error code
/// �ͷž���ڴ�
MRESULT HYIQ_Uninit(MHandle HYIQhandle )
{
    MLong  res=0;
    PIMQU PIMQ=(PIMQU)HYIQhandle;
    MHandle hMemMgr;
    hMemMgr=PIMQ->hMemMgr;
    FreeVectMem(hMemMgr,PIMQ);
EXT:
    return res;
}


/// \brief HYIQ_MemMgrCreate  allocate the memory for the handle
/// \param pMem the pointer
/// \param the memory length
/// \return the pointer
/// \�ڴ洴��
MHandle  HYIQ_MemMgrCreate(MVoid * pMem, MLong lMemSize)
{
     return JMemMgrCreate(pMem, lMemSize);
}


/// \brief HYIQ_MemMgrDestroy  Destroy the handle
/// \param hMemMgr Handle to destroy
/// \return null
/// \�ڴ��ͷ�
MVoid HYIQ_MemMgrDestroy(MHandle hMemMgr)
{
    JMemMgrDestroy(hMemMgr);
}





