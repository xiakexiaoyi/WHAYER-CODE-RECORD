#if !defined(_LI_IMG_FMT_TRANS_H_)
#define _LI_IMG_FMT_TRANS_H_

#include "licomdef.h"

#ifdef __cplusplus
extern "C" {
#endif

/*************************************************************/
#define ImgFmtTrans		PX(ImgFmtTrans)
/*************************************************************/
MRESULT ImgFmtTrans(PJOFFSCREEN pImgSrc, PJOFFSCREEN pImgRlt);
		   
#ifdef __cplusplus
}
#endif

#endif // !defined(_LI_IMG_FMT_TRANS_H_)
