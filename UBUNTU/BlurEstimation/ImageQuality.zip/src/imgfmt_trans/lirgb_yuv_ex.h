#if !defined(_LI_YUV_EX_H_)
#define _LI_YUV_EX_H_

#include "licomdef.h"
#include "lirgb_yuv.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif