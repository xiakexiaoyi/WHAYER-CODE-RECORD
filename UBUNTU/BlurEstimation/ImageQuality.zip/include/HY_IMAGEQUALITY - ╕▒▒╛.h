/*!
* \file HY_IMAGEQUALITY.h
* \brief  the API function
* \author hmy@whayer
* \version vision 1.0 
* \date 23 June 2014
*/

#ifndef _HY_IMAGEQUALITY_H
#define _HY_IMAGEQUALITY_H

#include"amcomdef.h"
#include <stdio.h>
//#include <opencv/cv.h>
//#include <opencv/cxcore.h>
//#include <opencv/highgui.h>

#ifdef ENABLE_DLL
#define IQ_API	__declspec(dllexport)
#else
#define	IQ_API
#endif



#ifdef __cplusplus
extern "C" {
#endif
	/* Defines for image color format*/
#define HY_IMAGE_GRAY				0x00		//chalk original 0x0A 	
#define HY_IMAGE_YUYV               0x02        //y,u,y,v,y,u,y,v......
#define HY_IMAGE_RGB                0x04        //r,g,b,r,g,b.....
#define HY_IMAGE_BGR                0x06        //b,g,r,b,g,r.....
#define HY_IMAGE_YUV420          0x08       //yuv420.....
#define MAX_DESCRITPTOR_NUMBER 1000             //һ�����е����������������
#define MAX_CLASS_NUMBER 100                    //����������������������
#define IMAGE_UNBLUR      900
#define IMAGE_TINYBLUR    901
#define IMAGE_MEDBLUR     902
#define IMAGE_HEVBLUR      903
#define IMAGE_UNNOISE     904
#define IMAGE_MEDNOISE    905
#define IMAGE_HEAVENOISE  906
#define IMAGE_TOODARK     907
#define IMAGE_TOOLIGHT    908
#define IMAGE_CAST        909
#define IMAGE_TINYNOISE   910
#define IMAGE_SIGNALLOST  911
#define IMAGE_FROZEN      912
#define IMAGE_COVERDUST     913

	/* Defines for image data*/
	typedef struct {
		MLong		lWidth;				// Off-screen width
		MLong		lHeight;			// Off-screen height
		MLong		lPixelArrayFormat;	// Format of pixel array
		union
		{
			struct
			{
				MLong lLineBytes; 
				MVoid *pPixel;
			} chunky;
			struct
			{
				MLong lLinebytesArray[4];
				MVoid *pPixelArray[4];
			} planar;
		} pixelArray;
	} IQ_IMAGES, *IQ_PIMAGES;

	/// \brief the image quality parameter struct
	typedef struct
	{
		MFloat BLURLEVEL; /// \blurlevel
		struct
		{
			MFloat sigma1;
			MFloat sigma2;
		}Sigma;
		MFloat NOISELEVEL; /// \noiselevel
		struct  
		{
			MFloat BrightLevel1;
			MFloat BrightLevel2;
			MFloat Brightderiv;/// \luminace derivation
		}Bright;
		struct  
		{
			MFloat Rcastratio; /// \ R castraitio
			MFloat Gcastratio; /// \G castratio
			MFloat Bcastratio; /// \B castratio
			MLong flag;
		}ImgCast;
		struct 
		{
			MLong flag;  /// \while flag=0, signal is normal,flag=1,signal lost,flag=2,signal frozen
		}Signal;

		MFloat CoverDustLevel; /// \blurlevel
	}HYIQ_TOutParam,*HYIQ_PTOutParam;
typedef struct  
{
	struct
	{
		MFloat BlurLevellowthresh;/// if blur level is less than this threshhold,the image is not blur
		MFloat Blurlevelhighthresh;///if blur level is larger than BlurLevellowthresh,but less than this ,the image is a litter blurred;
		MFloat Blurlevelhighthresh1;///if blur level is between Blurlevelhighthresh and Blurlevelhighthresh1,the image is median blurred,when the image is larger than Blurlevelhighthresh1,the image is seriouly blurred.
	}Blurlevel;
	struct
	{
		MFloat NoiseLevellowthresh;/// if blur level is less than this threshhold,the image is not too noise
		MFloat Noiselevelhighthresh;///if blur level is larger than BlurLevellowthresh,but less than this ,the image is a litter noise;
		MFloat Noiselevelhighthresh1;///if blur level is between Blurlevelhighthresh and Blurlevelhighthresh1,the image is median noise,when the image is larger than Blurlevelhighthresh1,the image is seriouly noise.
	}Noiselevel;
	struct
	{
		MFloat darkthresh; ///when small than this thresh,the image is too dark
		MFloat lightthresh;/// when larger than this thresh the image is too light

	}Light;
	MFloat castratio;///when larger than this ratio,the image is cast;

	MFloat CoverDustThreshold;
}CustomParam,*PCustomParam;
typedef struct 
{
	MLong Noisestatus; //�����б�״��
	MLong lightstatus; ///�����б�״��
	MLong blurstatus;  ///ģ���б�״��
	MLong caststatus;  ///ƫɫ�б�״��
	MLong signalstatus;  ///ͼ���ź��б�״��
	MLong coverDuststatus; ///ͼ���ɳ��б�״��
}HYIQ_result,*pHYIQ_result;

	/* Defines for error*/
#define HYIQ_ERR_NONE					0
#define HYIQ_ERR_UNKNOWN				-1
#define HYIQ_ERR_IMAGE_FORMAT			-101
#define HYIQ_ERR_IMAGE_SIZE_UNMATCH	    -102
#define HYIQ_ERR_ALLOC_MEM_FAIL		    -201
#define HYIQ_ERR_NO_FIND				-901

	IQ_API MHandle HYIQ_MemMgrCreate(MVoid * pMem, MLong lMemSize);
	IQ_API MVoid   HYIQ_MemMgrDestroy(MHandle hMemMgr);
	IQ_API MRESULT HYIQ_Init(MHandle hMemMgr,MHandle *pIQreg);
	IQ_API MRESULT HYIQ_NOISE(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam);
	IQ_API MRESULT HYIQ_SaveImage(MHandle hHandle,IQ_PIMAGES pImagesrc,const char* filename);
	IQ_API MRESULT HYIQ_LOST(MHandle hHandle,IQ_PIMAGES pImagesrc1,IQ_PIMAGES pImagesrc2,HYIQ_PTOutParam ptOutParam);
	IQ_API MRESULT HYIQ_BLUR(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam);

	IQ_API MRESULT HYIQ_COVERDUST(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1,HYIQ_PTOutParam ptOutParam);
	IQ_API MRESULT HYIQ_BRIGHT(MHandle hHandle,IQ_PIMAGES pImage,IQ_PIMAGES pImage1, HYIQ_PTOutParam ptOutParam);
	IQ_API MRESULT HYIQ_ENHANCE(MHandle hHandle,IQ_PIMAGES pImagesrc,IQ_PIMAGES pImageres);
	IQ_API MRESULT HYIQ_CAST(MHandle hHandle,IQ_PIMAGES pImage, HYIQ_PTOutParam ptOutParam );
	IQ_API MRESULT HYIQ_Uninit(MHandle HYIQhandle);
    IQ_API MRESULT HYIQ_RESULT(MHandle hHandle,HYIQ_PTOutParam ptOutParam,PCustomParam customp,pHYIQ_result result);

	typedef struct
	{
		MLong lCodebase;			// Codebase version number 
		MLong lMajor;				// major version number 
		MLong lMinor;				// minor version number
		MLong lBuild;				// Build version number, increasable only
		const MChar *Version;		// version in string form
		const MChar *BuildDate;	// latest build Date
		const MChar *CopyRight;	// copyright 
	} IQ_Version;
	IQ_API const IQ_Version * IQ_GetVersion();


#ifdef __cplusplus
}
#endif

#endif