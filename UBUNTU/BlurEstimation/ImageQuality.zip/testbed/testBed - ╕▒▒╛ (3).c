// testBed.cpp : main project file.

#include"amcomdef.h"
#include"IMAGEQUALITY.h"

#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>

#include <ctype.h>

#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>

#define WORK_BUFFER 2560*1920*5
#define STATIC_MEM
#define JLINE_BYTES(Width, BitCt)    (((long)(Width) * (BitCt) + 31) / 32 * 4)
//#define  ISVIDEO

int cutImage(IQ_PIMAGES pImage_,IQ_PIMAGES pImage)
{

	pImage_->pixelArray.chunky.pPixel=(MPChar)pImage->pixelArray.chunky.pPixel+((int)(0.2*pImage->lHeight)*pImage->pixelArray.chunky.lLineBytes);
	pImage_->lHeight=pImage->lHeight*0.6;
	pImage_->lWidth=pImage->lWidth;
	pImage_->pixelArray.chunky.lLineBytes=pImage->pixelArray.chunky.lLineBytes;
	pImage_->lPixelArrayFormat=pImage->lPixelArrayFormat;

	return 1;
}
#ifdef ISVIDEO
int main(int argc, char* argv[])
{
	MHandle HYIQHandle=MNull;
#ifdef STATIC_MEM
	MVoid *pMem=malloc(WORK_BUFFER);
	MHandle hMemMgr = HYIQ_MemMgrCreate(pMem,WORK_BUFFER);
#else
	MHandle hMemMgr = MNull;
#endif	
	IQ_IMAGES imgiq1={0};
	IQ_IMAGES imgiq2={0};
	IQ_IMAGES imgiq_temp={0};

	HYIQ_result testresult={0};
	HYIQ_TOutParam p1={0};

	IMQU *pImqu=NULL;
	FILE *fp;
	IplImage *pImage1;//��Ƶ ǰһ֡
	IplImage *pImage2;//��Ƶ ��ǰ֡
	IplImage *pImage_2;//��Ƶ ��ǰ֡

	CvRect rect;
	CvCapture * capture;
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	char filePath[MAX_PATH]="E:\\ip01\\1\\";
	char filePath_const[MAX_PATH];
	char fileName[MAX_PATH];

	int nImgnum;
	int nVideoNum;
	//ͳ�Ƽ����
	int nNotClearNum;
	int nHeavyNotClearNum;
	int nNoiseNum;
	int nHeavyNoiseNum;
	int nTooLightNum;
	int nTooDrakNum;
	int nCastNum;
	int nFrozemNum;
	int nLostNum;
	int nNormNum;
	int nLabelNorm;

	//int nDP;
	int k;
	int bufSize;

	nVideoNum=0;
	fp=fopen("..//result.txt","w");
	HYIQ_Init(hMemMgr,&HYIQHandle,50);
	cvNamedWindow("img2",1);

	strcpy(filePath_const,filePath);
	strcat(filePath,"\*.mp4");
	hFind = FindFirstFile(filePath, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) 
	{
		printf ("FindFirstFile failed (%d)\n", GetLastError());
		return -2;
	}
	memset(fileName,0,MAX_PATH);
	strcpy(fileName,filePath_const);
	strcat(fileName,FindFileData.cFileName);
	fprintf(fp,"\n\n%s\n",fileName);
	do
	{
		nVideoNum++;
		if (nVideoNum>1)
		{
			memset(fileName,0,MAX_PATH);
			strcpy(fileName,filePath_const);
			strcat(fileName,FindFileData.cFileName);
			fprintf(fp,"\n%s\n",fileName);
		} 

		capture = cvCreateFileCapture (fileName);  //��ȡ��Ƶ
		if(capture==NULL) 
		{
			printf("NO capture");    //��ȡ���ɹ������ʶ
			return 1;
		}; 
		pImage_2=cvQueryFrame(capture);              //ץȡ֡
		//for ͳ�ƽ��
		nImgnum=0;
		nNotClearNum=0;
		nHeavyNotClearNum=0;
		nNoiseNum=0;
		nHeavyNoiseNum=0;
		nTooLightNum=0;
		nTooDrakNum=0;
		nCastNum=0;
		nFrozemNum=0;
		nLostNum=0;
		nNormNum=0;

		while(nImgnum<100)
		{
			nImgnum++;
			nLabelNorm=0;
			pImage1=cvQueryFrame(capture);              //ץȡ֡
			if (!pImage1)
			{
				break;
			}
			pImage_2=cvCloneImage(pImage1);
			pImage2=cvCreateImage(cvSize(1920,1080),IPL_DEPTH_8U,3);
			cvResize(pImage_2,pImage2,1);

			cvShowImage("img2",pImage2);
			cvWaitKey(1);
			imgiq2.lHeight=pImage2->height;
			imgiq2.lWidth=pImage2->width;
			imgiq2.lPixelArrayFormat=HY_IMAGE_BGR;
			imgiq2.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage2->width,pImage2->depth*pImage2->nChannels);
			imgiq2.pixelArray.chunky.pPixel=pImage2->imageData;

			pImqu=(IMQU *)HYIQHandle;
			HYIQ_VideoQualityDiagnosis(HYIQHandle,&testresult,&imgiq2,&p1);  
			switch(testresult.clearstatus)
			{
			case(IMAGE_CLEAR):
				//fprintf(fp,"Image is clear\n");
				nLabelNorm++;
				break;
			case(IMAGE_NOTCLEAR):
				//fprintf(fp,"Image is not clear\n");
				nNotClearNum++;
				break;
			case(IMAGE_HEVNOTCLEAR):
				//fprintf(fp,"Image is heavy not clear \n");
				nHeavyNotClearNum++;
				break;
			default:
				break;
			}

			switch(testresult.Noisestatus)
			{
			case(IMAGE_UNNOISE):
				//fprintf(fp,"Image is not noise\n");
				nLabelNorm++;
				break;
			case(IMAGE_NOISE):
				//fprintf(fp,"Image is  noised\n");
				nNoiseNum++;
				break;
			case(IMAGE_HEAVENOISE):
				//fprintf(fp,"Image is heavy noise\n");
				nHeavyNoiseNum++;
				break;
			default:
				break;
			}

			switch(testresult.lightstatus)
			{
			case(IMAGE_TOODARK):
				//fprintf(fp,"Image is too dark\n");
				nTooDrakNum++;
				break;
			case(IMAGE_TOOLIGHT):
				//fprintf(fp,"Image is too light\n");
				nTooLightNum++;
				break;
			default:
				nLabelNorm++;
				break;
			}

			switch(testresult.signalLoststatus)
			{
			case(IMAGE_CAST):
				//fprintf(fp,"Image is cast\n");
				nCastNum++;
				break;
			default:
				//fprintf(fp,"Image is not cast\n");
				nLabelNorm++;
				break;
			}

			switch(testresult.signalLoststatus)
			{
			case(IMAGE_SIGNALLOST):
				//fprintf(fp,"Image is frozen\n");
				nLostNum++;
				break;
			default:
				nLabelNorm++;
				break;
			}

			switch(testresult.imgFrozenstatus)
			{
			case(IMAGE_FROZEN):
				//fprintf(fp,"Image is frozen\n");
				nFrozemNum++;
				break;
			default:
				nLabelNorm++;
				break;
			}

			if (nLabelNorm==6)
			{
				nNormNum++;
			}

			if (pImqu->pImgBufs->size==50)
			{
				DeQueue(pImqu->pImgBufs,&imgiq_temp);
				cvFree(&imgiq_temp.pixelArray.chunky.pPixel);
			}

			//fprintf(fp,"noise level = %10f\n",p1.NOISELEVEL);
			//fprintf(fp,"clear level = %10f\n",p1.CLEARLEVEL);
			//fprintf(fp,"luminance saturation = %10f\n",p1.Bright.BrightLevel1);
			//fprintf(fp,"\n");
			//cvReleaseImageHeader(&pImage2);
			cvReleaseImage(&pImage_2);
			pImage2=NULL;
		}

		//���ͳ�ƽ��
		fprintf(fp,"NotClearNum= %d\n",nNotClearNum);
		fprintf(fp,"HeavyNotClearNum= %d\n",nHeavyNotClearNum);
		fprintf(fp,"NoiseNum= %d\n",nNoiseNum);
		fprintf(fp,"HeavyNoiseNum= %d\n",nHeavyNoiseNum);
		fprintf(fp,"TooLightNum= %d\n",nTooLightNum);
		fprintf(fp,"TooDrakNum= %d\n",nTooDrakNum);
		fprintf(fp,"CastNum= %d\n",nCastNum);
		fprintf(fp,"FrozemNum= %d\n",nFrozemNum);
		fprintf(fp,"LostNum= %d\n",nLostNum);
		fprintf(fp,"NormNum= %d\n",nNormNum);
		fprintf(fp,"Imgnum= %d\n",nImgnum);

		//�ͷ��ڴ�
		//pImqu=(IMQU *)HYIQHandle;
		bufSize=GetSize(pImqu->pImgBufs);
		for (k=0;k<bufSize;k++)
		{
			DeQueue(pImqu->pImgBufs,&imgiq_temp);
			cvFree(&imgiq_temp.pixelArray.chunky.pPixel);
		}
		ClearQueue(pImqu->pImgBufs);  
		cvReleaseCapture(&capture);
		capture=NULL;
	}while (FindNextFile(hFind, &FindFileData));

	fclose (fp); 
	HYIQ_Uninit(HYIQHandle);

	if (pImage2!=NULL)
	{
	 cvReleaseImage(&pImage2);
	 pImage2=NULL;
	}

	cvDestroyAllWindows();
	//DestroyQueue(pImgBufs); 
#ifdef STATIC_MEM
	HYIQ_MemMgrDestroy(hMemMgr);
	free(pMem);
#endif

	return 0;
}

#else
int main(int argc, char* argv[])
{
	MHandle HYIQHandle=MNull;
#ifdef STATIC_MEM
	MVoid *pMem=malloc(WORK_BUFFER);
	MHandle hMemMgr = HYIQ_MemMgrCreate(pMem,WORK_BUFFER);
#else
	MHandle hMemMgr = MNull;
#endif

	IQ_IMAGES imgiq1={0};
	IQ_IMAGES imgiq2={0};
	IQ_IMAGES imgiq1_={0};
	IQ_IMAGES imgiq2_={0};
	IQ_IMAGES imgiq_temp={0};

	HYIQ_TOutParam p1={0};
	HYIQ_result testresult={0};
	IMQU *pImqu=NULL;

	FILE *fp;
	IplImage *pImage1;//��Ƶ ǰһ֡
	IplImage *pImage2;//��Ƶ ��ǰ֡

	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	char filePath[MAX_PATH]="D:\\TestData\\VideoQualityDiagnosis\\lost\\";
	char filePath_const[MAX_PATH];
	char fileName1[MAX_PATH];
	char fileName2[MAX_PATH];

	int nImgnum;
	//ͳ�Ƽ����
	int nNotClearNum;
	int nHeavyNotClearNum;
	int nNoiseNum;
	int nHeavyNoiseNum;
	int nTooLightNum;
	int nTooDrakNum;
	int nCastNum;
	int nFrozemNum;
	int nLostNum;
	int nNormNum;
	int nLabelNorm;
	
	int k;
	int bufSize;

	nImgnum=0;
	nNotClearNum=0;
	nHeavyNotClearNum=0;
	nNoiseNum=0;
	nHeavyNoiseNum=0;
	nTooLightNum=0;
	nTooDrakNum=0;
	nCastNum=0;
	nFrozemNum=0;
	nLostNum=0;
	nNormNum=0;
	fp=fopen("..//result.txt","w");
	HYIQ_Init(hMemMgr,&HYIQHandle,2);
	//cvNamedWindow("img2",1);

	strcpy(filePath_const,filePath);
	strcat(filePath,"\*.jpeg");
	hFind = FindFirstFile(filePath, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) 
	{
		printf ("FindFirstFile failed (%d)\n", GetLastError());
		return -2;
	}

	memset(fileName1,0,MAX_PATH);
	strcpy(fileName1,filePath_const);
	strcat(fileName1,FindFileData.cFileName);
	fprintf(fp,"%s\n",fileName1);
	while (FindNextFile(hFind, &FindFileData))
	{  	
		nImgnum++;
		nLabelNorm=0;
		//testresult.clearstatus=0;
		//testresult.caststatus=0;
		//testresult.lightstatus=0;
		//testresult.Noisestatus=0;
		//testresult.signalLoststatus=0;
		//testresult.imgFrozenstatus=0;

		//p1.CLEAR.CLEARLEVEL=0;
		//p1.Bright.BrightLevel1=0;
		//p1.Bright.BrightLevel2=0;
		//p1.Bright.Brightderiv=0;
		//p1.ImgCast.flag=0;
		//p1.NOISE.NOISELEVEL=0;
		//p1.SignalLost.flag=0;
		//p1.ImgFrozen.flag=0;

		if (nImgnum==1)
		{
			memset(fileName2,0,MAX_PATH);
			strcpy(fileName2,filePath_const);
			strcat(fileName2,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName2);
		}
		else
		{
			memset(fileName1,0,MAX_PATH);
			strcpy(fileName1,filePath_const);
			strcat(fileName1,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName1);
			FindNextFile(hFind, &FindFileData);
			memset(fileName2,0,MAX_PATH);
			strcpy(fileName2,filePath_const);
			strcat(fileName2,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName2);
		}

		//���ļ��ж�ȡͼ��  
		pImage1 = cvLoadImage(fileName1/*"D:\\1\\8_0.jpeg"*/, CV_LOAD_IMAGE_UNCHANGED);  
		pImage2 = cvLoadImage(fileName2/*"D:\\1\\8_1.jpeg"*/, CV_LOAD_IMAGE_UNCHANGED);


		imgiq1.lHeight=pImage1->height;
		imgiq1.lWidth=pImage1->width;
		imgiq1.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq1.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage1->width,pImage1->depth*pImage1->nChannels);
		imgiq1.pixelArray.chunky.pPixel=pImage1->imageData;
		cutImage(&imgiq1_,&imgiq1);
		pImqu=(IMQU *)HYIQHandle;
		HYIQ_VideoQualityDiagnosis(HYIQHandle,&testresult,&imgiq1,&p1);
		imgiq2.lHeight=pImage2->height;
		imgiq2.lWidth=pImage2->width;
		imgiq2.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq2.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage2->width,pImage2->depth*pImage2->nChannels);
		imgiq2.pixelArray.chunky.pPixel=pImage2->imageData;
		cutImage(&imgiq2_,&imgiq2);

		pImqu=(IMQU *)HYIQHandle;
		//cvShowImage("src",pImage1);
		//cvWaitKey(0);
		HYIQ_VideoQualityDiagnosis(HYIQHandle,&testresult,&imgiq2,&p1);
		bufSize=GetSize(pImqu->pImgBufs);
		for (k=0;k<bufSize;k++)
		{
			DeQueue(pImqu->pImgBufs,&imgiq_temp);
			cvFree(&imgiq_temp.pixelArray.chunky.pPixel);
		}
		ClearQueue(pImqu->pImgBufs);
		

		switch(testresult.clearstatus)
		{
		case(IMAGE_CLEAR):
			fprintf(fp,"Image is clear\n");
			nLabelNorm++;
			break;
		case(IMAGE_NOTCLEAR):
			fprintf(fp,"Image is not clear\n");
			nNotClearNum++;
			break;
		case(IMAGE_HEVNOTCLEAR):
			fprintf(fp,"Image is heavy not clear \n");
			nHeavyNotClearNum++;
			break;
		default:
			break;
		}

		switch(testresult.Noisestatus)
		{
		case(IMAGE_UNNOISE):
			fprintf(fp,"Image is not noise\n");
			nLabelNorm++;
			break;
		case(IMAGE_NOISE):
			fprintf(fp,"Image is  noised\n");
			nNoiseNum++;
			break;
		case(IMAGE_HEAVENOISE):
			fprintf(fp,"Image is heavy noise\n");
			nHeavyNoiseNum++;
			break;
		default:
			break;
		}

		switch(testresult.lightstatus)
		{
		case(IMAGE_TOODARK):
			fprintf(fp,"Image is too dark\n");
			nTooDrakNum++;
			break;
		case(IMAGE_TOOLIGHT):
			fprintf(fp,"Image is too light\n");
			nTooLightNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}

		switch(testresult.caststatus)
		{
		case(IMAGE_CAST):
			fprintf(fp,"Image is cast\n");
			nCastNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}

		switch(testresult.signalLoststatus)
		{  
		case (IMAGE_SIGNALLOST):
			fprintf(fp,"Signal is lost\n");
			nLostNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}
		switch(testresult.imgFrozenstatus)
		{
		case(IMAGE_FROZEN):
			fprintf(fp,"Image is frozen\n");
			nFrozemNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}

		if (nLabelNorm==6)
		{
			nNormNum++;
		}
		fprintf(fp,"noise level = %10f\n",p1.NOISE.NOISELEVEL);
		fprintf(fp,"clear level = %10f\n",p1.CLEAR.CLEARLEVEL);
		fprintf(fp,"luminance saturation = %10f\n",p1.Bright.BrightLevel1);
		//fprintf(fp,"coverDust level = %10f\n",p1.CoverDustLevel);
		fprintf(fp,"\n\n");
	} 

	fprintf(fp,"NotClearNum= %d\n",nNotClearNum);
	fprintf(fp,"HeavyNotClearNum= %d\n",nHeavyNotClearNum);
	fprintf(fp,"NoiseNum= %d\n",nNoiseNum);
	fprintf(fp,"HeavyNoiseNum= %d\n",nHeavyNoiseNum);
	fprintf(fp,"TooLightNum= %d\n",nTooLightNum);
	fprintf(fp,"TooDrakNum= %d\n",nTooDrakNum);
	fprintf(fp,"CastNum= %d\n",nCastNum);
	fprintf(fp,"FrozemNum= %d\n",nFrozemNum);
	fprintf(fp,"LostNum= %d\n",nLostNum);
	//fprintf(fp,"CoverDustNum= %d\n",nCoverDustNum);
	fprintf(fp,"NormNum= %d\n",nNormNum);
	fprintf(fp,"Imgnum= %d\n",nImgnum);
	fclose (fp); 
	HYIQ_Uninit(HYIQHandle);
	//if (pImage1!=NULL)
	//{
	//	cvReleaseImage(&pImage1);
	//	pImage1=NULL;
	//}

	//if (pImage2!=NULL)
	//{
	//	cvReleaseImage(&pImage2);
	//	pImage2=NULL;
	//}

	cvDestroyAllWindows();

#ifdef STATIC_MEM
	HYIQ_MemMgrDestroy(hMemMgr);
	free(pMem);
#endif

	return 0;
}
#endif