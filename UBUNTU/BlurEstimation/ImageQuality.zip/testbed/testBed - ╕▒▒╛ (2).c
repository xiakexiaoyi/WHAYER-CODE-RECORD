// testBed.cpp : main project file.

#include"amcomdef.h"
#include"HY_IMAGEQUALITY.h"

#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>

#define WORK_BUFFER 2560*1920*5
#define STATIC_MEM
#define JLINE_BYTES(Width, BitCt)    (((long)(Width) * (BitCt) + 31) / 32 * 4)
#define  ISVIDEO
//#define IMGBUFSIZE 50

#ifdef ISVIDEO
int main(int argc, char* argv[])
{
	MHandle HYIQHandle=MNull;
#ifdef STATIC_MEM
	MVoid *pMem=malloc(WORK_BUFFER);
	MHandle hMemMgr = HYIQ_MemMgrCreate(pMem,WORK_BUFFER);
#else
	MHandle hMemMgr = MNull;
#endif	
	IQ_IMAGES imgiq1={0};
	IQ_IMAGES imgiq2={0};
	//IQ_IMAGES imgiq1_={0};//ƫ�� �������±߽�
	//IQ_IMAGES imgiq2_={0};//ƫ�� �������±߽�
	//Whayer_Queue *pImgBufs;
	IQ_IMAGES imgiq_temp={0};
	//IQ_IMAGES imgiq_front={0};
	//IQ_IMAGES imgiq_end={0};
    
	//HYIQ_TOutParam p1={0};
	//CustomParam custopar={0};
	HYIQ_result testresult={0};

	IMQU *pImqu=NULL;
	FILE *fp;
	IplImage *pImage1;//��Ƶ ǰһ֡
	IplImage *pImage2;//��Ƶ ��ǰ֡
	//IplImage *pShowImg;
	//IplImage *pShowImg1;
	//IplImage *pShowImg2;
	//IplImage *pImageSrc1;//��Ƶ ǰһ֡
	//IplImage *pImageSrc2;//��Ƶ ��ǰ֡
	CvRect rect;
	CvCapture * capture;
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	char filePath[MAX_PATH]="E:\\ipc02\\frozen\\";
	char filePath_const[MAX_PATH];
	char fileName[MAX_PATH];

	int nImgnum;
	int nVideoNum;
	//ͳ�Ƽ����
	int nNotClearNum;
	int nHeavyNotClearNum;
	int nNoiseNum;
	int nHeavyNoiseNum;
	int nTooLightNum;
	int nTooDrakNum;
	int nCastNum;
	int nFrozemNum;
	int nLostNum;
	int nNormNum;

	//int nDP;
	int k;
	int bufSize;

	nVideoNum=0;
	fp=fopen("..//result.txt","w");
	HYIQ_Init(hMemMgr,&HYIQHandle);
	cvNamedWindow("img2",1);
	//cvNamedWindow("showimg2",1);
	//cvNamedWindow("img_front",1);
	//cvNamedWindow("img_end",1);

	strcpy(filePath_const,filePath);
	strcat(filePath,"\*.mp4");
	hFind = FindFirstFile(filePath, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) 
	{
		printf ("FindFirstFile failed (%d)\n", GetLastError());
		return -2;
	}
	memset(fileName,0,MAX_PATH);
	strcpy(fileName,filePath_const);
	strcat(fileName,FindFileData.cFileName);
	fprintf(fp,"\n\n%s\n",fileName);
	do
	{
		nVideoNum++;
		if (nVideoNum>1)
		{
			memset(fileName,0,MAX_PATH);
			strcpy(fileName,filePath_const);
			strcat(fileName,FindFileData.cFileName);
			fprintf(fp,"\n%s\n",fileName);
		} 

		capture = cvCreateFileCapture (fileName);  //��ȡ��Ƶ
		if(capture==NULL) 
		{
			printf("NO capture");    //��ȡ���ɹ������ʶ
			return 1;
		}; 
		pImage2=cvQueryFrame( capture );              //ץȡ֡
       // pShowImg=cvCreateImage(cvSize(pImage2->width,pImage2->height*0.6),IPL_DEPTH_8U,3);
		//for ͳ�ƽ��
		nImgnum=0;
		nNotClearNum=0;
		nHeavyNotClearNum=0;
		nNoiseNum=0;
		nHeavyNoiseNum=0;
		nTooLightNum=0;
		nTooDrakNum=0;
		nCastNum=0;
		nFrozemNum=0;
		nLostNum=0;
		nNormNum=0;

		while(nImgnum<100)
		{
	        nImgnum++;
			//pImage2=cvCreateImage(cvSize(pImage2->width,pImage2->height*0.6),IPL_DEPTH_8U,3);
			pImage1=cvQueryFrame( capture );              //ץȡ֡
			pImage2=cvCloneImage(pImage1);
			if(!pImage2)
				break; 
			cvShowImage("img2",pImage2);
			cvWaitKey(1);
			imgiq2.lHeight=pImage2->height;
			imgiq2.lWidth=pImage2->width;
			imgiq2.lPixelArrayFormat=HY_IMAGE_BGR;
			imgiq2.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage2->width,pImage2->depth*pImage2->nChannels);
			imgiq2.pixelArray.chunky.pPixel=pImage2->imageData;
 
			HYIQ_SENDDATA(HYIQHandle,&imgiq2);
			pImqu=(IMQU *)HYIQHandle;
			if(pImqu->pImgBufs->size==IMGBUFSIZE)
			{
				HYIQ_VideoQualityDiagnosis(HYIQHandle,&testresult);  
				switch(testresult.clearstatus)
				{
				case(IMAGE_CLEAR):
					//fprintf(fp,"Image is clear\n");
					nNormNum++;
					break;
				case(IMAGE_NOTCLEAR):
					//fprintf(fp,"Image is not clear\n");
					nNotClearNum++;
					break;
				case(IMAGE_HEVNOTCLEAR):
					//fprintf(fp,"Image is heavy not clear \n");
					nHeavyNotClearNum++;
					break;
				default:
					break;
				}

				switch(testresult.Noisestatus)
				{
				case(IMAGE_NOISE):
					//fprintf(fp,"Image is  noised\n");
					nNoiseNum++;
					break;
				case(IMAGE_HEAVENOISE):
					//fprintf(fp,"Image is heavy noise\n");
					nHeavyNoiseNum++;
					break;
				default:
					break;
				}

				switch(testresult.lightstatus)
				{
				case(IMAGE_TOODARK):
					//fprintf(fp,"Image is too dark\n");
					nTooDrakNum++;
					break;
				case(IMAGE_TOOLIGHT):
					//fprintf(fp,"Image is too light\n");
					nTooLightNum++;
					break;
				default:
					break;
				}

				if(testresult.caststatus==IMAGE_CAST)
				{
					//fprintf(fp,"Image is cast\n");
					nCastNum++;
				}

				if(testresult.signalLoststatus==IMAGE_SIGNALLOST)
				{
					//fprintf(fp,"Image is cast\n");
					nLostNum++;
				}

				switch(testresult.imgFrozenstatus==IMAGE_FROZEN)
				{
					//fprintf(fp,"Image is frozen\n");
					nFrozemNum++;
					break;
				}
				DeQueue(pImqu->pImgBufs,&imgiq_temp);
				cvFree(&imgiq_temp.pixelArray.chunky.pPixel);
			} 

			////fprintf(fp,"noise level = %10f\n",p1.NOISELEVEL);
			////fprintf(fp,"blur level = %10f\n",p1.CLEARLEVEL);
			////fprintf(fp,"luminance saturation = %10f\n",p1.Bright.BrightLevel1);
			////fprintf(fp,"\n");
			//cvReleaseImageHeader(&pImage1);
			//pImage1=NULL;
		}
       
		//���ͳ�ƽ��
		fprintf(fp,"NotClearNum= %d\n",nNotClearNum);
		fprintf(fp,"HeavyNotClearNum= %d\n",nHeavyNotClearNum);
		fprintf(fp,"NoiseNum= %d\n",nNoiseNum);
		fprintf(fp,"HeavyNoiseNum= %d\n",nHeavyNoiseNum);
		fprintf(fp,"TooLightNum= %d\n",nTooLightNum);
		fprintf(fp,"TooDrakNum= %d\n",nTooDrakNum);
		fprintf(fp,"CastNum= %d\n",nCastNum);
		fprintf(fp,"FrozemNum= %d\n",nFrozemNum);
		fprintf(fp,"LostNum= %d\n",nLostNum);
		fprintf(fp,"NormNum= %d\n",nNormNum);
		fprintf(fp,"Imgnum= %d\n",nImgnum);
  
		//�ͷ��ڴ�
		//pImqu=(IMQU *)HYIQHandle;
		bufSize=GetSize(pImqu->pImgBufs);
		for (k=0;k<bufSize;k++)
		{
			DeQueue(pImqu->pImgBufs,&imgiq_temp);
			cvFree(&imgiq_temp.pixelArray.chunky.pPixel);
		}
		ClearQueue(pImqu->pImgBufs);  
		cvReleaseCapture(&capture);
		capture=NULL;
	}while (FindNextFile(hFind, &FindFileData));

	fclose (fp); 
	HYIQ_Uninit(HYIQHandle);
	//if (pImage2!=NULL)
	//{
	// cvReleaseImage(&pImage2);
	// pImage2=NULL;
	//}

	cvDestroyAllWindows();
    //DestroyQueue(pImgBufs); 
#ifdef STATIC_MEM
	HYIQ_MemMgrDestroy(hMemMgr);
	free(pMem);
#endif

	return 0;
}

#else
int main(int argc, char* argv[])
{
	MHandle HYIQHandle=MNull;
#ifdef STATIC_MEM
	MVoid *pMem=malloc(WORK_BUFFER);
	MHandle hMemMgr = HYIQ_MemMgrCreate(pMem,WORK_BUFFER);
#else
	MHandle hMemMgr = MNull;
#endif

	IQ_IMAGES imgiq1={0};
	IQ_IMAGES imgiq2={0};
	IQ_IMAGES imgiq1_={0};//ƫ�� �������±߽�
	IQ_IMAGES imgiq2_={0};//ƫ�� �������±߽�
	//char image_name1[MAX_PATH];
	//char image_name2[MAX_PATH];
	HYIQ_TOutParam p1={0};
	CustomParam custopar={0};
	HYIQ_result testresult={0};

	FILE *fp;
	IplImage *pImage1;//��Ƶ ǰһ֡
	IplImage *pImage2;//��Ƶ ��ǰ֡
	IplImage *pShowImg;
	//IplImage *pImageSrc1;//��Ƶ ǰһ֡
	//IplImage *pImageSrc2;//��Ƶ ��ǰ֡
	CvRect rect;
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	char filePath[MAX_PATH]="D:\\TestData\\VideoQualityDiagnosis\\1\\1\\";
	char filePath_const[MAX_PATH];
	char fileName1[MAX_PATH];
	char fileName2[MAX_PATH];

	int nImgnum;
	//ͳ�Ƽ����
	int nNotClearNum;
	int nHeavyNotClearNum;
	int nNoiseNum;
	int nHeavyNoiseNum;
	int nTooLightNum;
	int nTooDrakNum;
	int nCastNum;
	int nFrozemNum;
	int nLostNum;
	int nNormNum;
	int nLabelNorm;
	int nCoverDustNum;
	int nDP;

	nImgnum=0;
	nNotClearNum=0;
	nHeavyNotClearNum=0;
	nNoiseNum=0;
	nHeavyNoiseNum=0;
	nTooLightNum=0;
	nTooDrakNum=0;
	nCastNum=0;
	nFrozemNum=0;
	nLostNum=0;
	nCoverDustNum=0;
	nNormNum=0;
	fp=fopen("..//result.txt","w");
	HYIQ_Init(hMemMgr,&HYIQHandle);
	cvNamedWindow("img",1);
	cvNamedWindow("showimg",1);

	strcpy(filePath_const,filePath);
	strcat(filePath,"\*.jpeg");
	hFind = FindFirstFile(filePath, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) 
	{
		printf ("FindFirstFile failed (%d)\n", GetLastError());
		return -2;
	}

	memset(fileName1,0,MAX_PATH);
	strcpy(fileName1,filePath_const);
	strcat(fileName1,FindFileData.cFileName);
	fprintf(fp,"%s\n",fileName1);
	while (FindNextFile(hFind, &FindFileData))
	{  	
		nImgnum++;
		nLabelNorm=0;
		testresult.clearstatus=0;
		testresult.caststatus=0;
		testresult.lightstatus=0;
		testresult.Noisestatus=0;
		testresult.signalLoststatus=0;
		testresult.imgFrozenstatus=0;


		p1.CLEARLEVEL=0;
		p1.Bright.BrightLevel1=0;
		p1.Bright.BrightLevel2=0;
		p1.Bright.Brightderiv=0;
		p1.ImgCast.flag=0;
		p1.NOISELEVEL=0;
		p1.SignalLost.flag=0;
		p1.ImgFrozen.flag=0;

		if (nImgnum==1)
		{
			memset(fileName2,0,MAX_PATH);
			strcpy(fileName2,filePath_const);
			strcat(fileName2,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName2);
		}
		else
		{
			memset(fileName1,0,MAX_PATH);
			strcpy(fileName1,filePath_const);
			strcat(fileName1,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName1);
			FindNextFile(hFind, &FindFileData);
			memset(fileName2,0,MAX_PATH);
			strcpy(fileName2,filePath_const);
			strcat(fileName2,FindFileData.cFileName);
			fprintf(fp,"%s\n",fileName2);
		}

		//���ļ��ж�ȡͼ��  
		pImage1 = cvLoadImage(fileName1/*"D:\\1\\8_0.jpeg"*/, CV_LOAD_IMAGE_UNCHANGED);  
		pImage2 = cvLoadImage(fileName2/*"D:\\1\\8_1.jpeg"*/, CV_LOAD_IMAGE_UNCHANGED);

		pShowImg=cvCreateImage(cvSize(pImage1->width,pImage1->height*0.6),IPL_DEPTH_8U,3);
		//pImage1=cvCreateImage(cvSize(pImageSrc1->width,pImageSrc1->height*0.6),IPL_DEPTH_8U,3);
		//pImage2=cvCreateImage(cvSize(pImageSrc2->width,pImageSrc2->height*0.6),IPL_DEPTH_8U,3);
		//      rect.width=pImageSrc1->width;
		//rect.height=pImageSrc1->height*0.6;
		//rect.x=0;
		//rect.y=pImageSrc1->height*0.2;
		////��ͼ������ȡ��ͼ��
		//cvSetImageROI(pImageSrc1, rect);
		//cvCopy(pImageSrc1, pImage1,NULL);
		//cvResetImageROI(pImageSrc1);
		//cvSetImageROI(pImageSrc2, rect);
		//cvCopy(pImageSrc2, pImage2,NULL);
		//cvResetImageROI(pImageSrc2);
		//cvReleaseImage(&pImageSrc1);
		//cvReleaseImage(&pImageSrc2);

		cvShowImage("img",pImage1);
		cvWaitKey(2);
		imgiq1.lHeight=pImage1->height;
		imgiq1.lWidth=pImage1->width;
		imgiq1.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq1.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage1->width,pImage1->depth*pImage1->nChannels);
		imgiq1.pixelArray.chunky.pPixel=pImage1->imageData;

		imgiq1_.lHeight=pImage1->height;
		imgiq1_.lWidth=pImage1->width;
		imgiq1_.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq1_.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage1->width,pImage1->depth*pImage1->nChannels);
		imgiq1_.pixelArray.chunky.pPixel=pImage1->imageData+((int)(0.2*pImage1->height)*imgiq1.pixelArray.chunky.lLineBytes);
		imgiq1_.lHeight=pImage1->height*0.6;

		imgiq2.lHeight=pImage2->height;
		imgiq2.lWidth=pImage2->width;
		imgiq2.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq2.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage2->width,pImage2->depth*pImage2->nChannels);
		imgiq2.pixelArray.chunky.pPixel=pImage2->imageData;

		imgiq2_.lHeight=pImage2->height;
		imgiq2_.lWidth=pImage2->width;
		imgiq2_.lPixelArrayFormat=HY_IMAGE_BGR;
		imgiq2_.pixelArray.chunky.lLineBytes=JLINE_BYTES(pImage2->width,pImage2->depth*pImage2->nChannels);
		imgiq2_.pixelArray.chunky.pPixel=pImage2->imageData+((int)(0.2*pImage2->height)*imgiq2.pixelArray.chunky.lLineBytes);
		imgiq2_.lHeight= imgiq2_.lHeight*0.6;

		pShowImg->imageData=imgiq1_.pixelArray.chunky.pPixel;
		cvShowImage("showimg",pShowImg);
		cvWaitKey(0);

		HYIQ_LOST(HYIQHandle,&imgiq1,&imgiq2,&p1);
		HYIQ_FROZEN(HYIQHandle,&imgiq1,&imgiq2,&p1);

		HYIQ_BRIGHT(HYIQHandle,&imgiq1_,&imgiq2_,&p1);//�������Ⱦ�ֵ�;�ֵ��
		if (p1.Bright.Brightderiv<0.3)
		{
			HYIQ_NOISE(HYIQHandle,&imgiq1_,&imgiq2_,&p1);
			if (p1.Bright.BrightLevel1>-0.45&&p1.Bright.BrightLevel2>-0.45)//����
			{
				HYIQ_CLEAR(HYIQHandle,&imgiq1_,&imgiq2_,&p1);//���������
				//HYIQ_COVERDUST(HYIQHandle,&imgiq1,&imgiq2,&p1);
				HYIQ_CAST(HYIQHandle,&imgiq1_,&p1);//ƫɫ  ���������
			}
		}
		HYIQ_RESULT(HYIQHandle,&p1,&custopar,&testresult);

		switch(testresult.clearstatus)
		{
		case(IMAGE_CLEAR):
			fprintf(fp,"Image is clear\n");
			nLabelNorm++;
			break;
		case(IMAGE_NOTCLEAR):
			fprintf(fp,"Image is not clear\n");
			nNotClearNum++;
			break;
		case(IMAGE_HEVNOTCLEAR):
			fprintf(fp,"Image is heavy not clear \n");
			nHeavyNotClearNum++;
			break;
		default:
			break;
		}

		switch(testresult.Noisestatus)
		{
		case(IMAGE_UNNOISE):
			fprintf(fp,"Image is not noise\n");
			nLabelNorm++;
			break;
		case(IMAGE_NOISE):
			fprintf(fp,"Image is  noised\n");
			nNoiseNum++;
			break;
		case(IMAGE_HEAVENOISE):
			fprintf(fp,"Image is heavy noise\n");
			nHeavyNoiseNum++;
			break;
		default:
			break;
		}

		switch(testresult.lightstatus)
		{
		case(IMAGE_TOODARK):
			fprintf(fp,"Image is too dark\n");
			nTooDrakNum++;
			break;
		case(IMAGE_TOOLIGHT):
			fprintf(fp,"Image is too light\n");
			nTooLightNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}

		if(testresult.caststatus==IMAGE_CAST)
		{
			fprintf(fp,"Image is cast\n");
			nCastNum++;
		}
		else
		{
			fprintf(fp,"Image is not cast\n");
			nLabelNorm++;
		}

		switch(testresult.signalLoststatus)
		{
		case (IMAGE_SIGNALLOST):
			fprintf(fp,"Signal is lost\n");
			nLostNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}
		switch(testresult.imgFrozenstatus)
		{
		case(IMAGE_FROZEN):
			fprintf(fp,"Image is frozen\n");
			nFrozemNum++;
			break;
		default:
			nLabelNorm++;
			break;
		}

		if (nLabelNorm==6)
		{
			nNormNum++;
		}
		fprintf(fp,"noise level = %10f\n",p1.NOISELEVEL);
		fprintf(fp,"blur level = %10f\n",p1.CLEARLEVEL);
		fprintf(fp,"luminance saturation = %10f\n",p1.Bright.BrightLevel1);
		//fprintf(fp,"coverDust level = %10f\n",p1.CoverDustLevel);
		fprintf(fp,"\n\n");
	} 

	fprintf(fp,"NotClearNum= %d\n",nNotClearNum);
	fprintf(fp,"HeavyNotClearNum= %d\n",nHeavyNotClearNum);
	fprintf(fp,"NoiseNum= %d\n",nNoiseNum);
	fprintf(fp,"HeavyNoiseNum= %d\n",nHeavyNoiseNum);
	fprintf(fp,"TooLightNum= %d\n",nTooLightNum);
	fprintf(fp,"TooDrakNum= %d\n",nTooDrakNum);
	fprintf(fp,"CastNum= %d\n",nCastNum);
	fprintf(fp,"FrozemNum= %d\n",nFrozemNum);
	fprintf(fp,"LostNum= %d\n",nLostNum);
	//fprintf(fp,"CoverDustNum= %d\n",nCoverDustNum);
	fprintf(fp,"NormNum= %d\n",nNormNum);
	fprintf(fp,"Imgnum= %d\n",nImgnum);
	fclose (fp); 
	HYIQ_Uninit(HYIQHandle);
	if (pImage1!=NULL)
	{
		cvReleaseImage(&pImage1);
		pImage1=NULL;
	}

	if (pImage2!=NULL)
	{
	 cvReleaseImage(&pImage2);
	 pImage2=NULL;
	}

	cvDestroyAllWindows();

#ifdef STATIC_MEM
	HYIQ_MemMgrDestroy(hMemMgr);
	free(pMem);
#endif

	return 0;
}
#endif

