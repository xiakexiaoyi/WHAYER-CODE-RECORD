#ifndef __INIT_DLL_H__
#define __INIT_DLL_H__
#ifdef _MSC_VER
#include "stdint.h"
#else
#include <sys/types.h>
#endif











#endif