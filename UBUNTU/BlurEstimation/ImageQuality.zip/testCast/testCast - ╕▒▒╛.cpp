#include <core/core.hpp>
#include <highgui/highgui.hpp>
#include <vector>
#include <iostream>

#pragma comment(lib,"opencv_calib3d244d.lib")
#pragma comment(lib,"opencv_contrib244d.lib")
#pragma comment(lib,"opencv_core244d.lib")
#pragma comment(lib,"opencv_features2d244d.lib")
#pragma comment(lib,"opencv_flann244d.lib")
#pragma comment(lib,"opencv_gpu244d.lib")
//#pragma comment(lib,"opencv_haartraining_engine.lib")
#pragma comment(lib,"opencv_highgui244d.lib")
#pragma comment(lib,"opencv_imgproc244d.lib")
#pragma comment(lib,"opencv_legacy244d.lib")
#pragma comment(lib,"opencv_ml244d.lib")
#pragma comment(lib,"opencv_nonfree244d.lib")
#pragma comment(lib,"opencv_objdetect244d.lib")
#pragma comment(lib,"opencv_photo244d.lib")
#pragma comment(lib,"opencv_stitching244d.lib")
#pragma comment(lib,"opencv_ts244d.lib")
#pragma comment(lib,"opencv_video244d.lib")
#pragma comment(lib,"opencv_videostab244d.lib")


#pragma comment(lib,"IlmImfd.lib")
#pragma comment(lib,"libjasperd.lib")
#pragma comment(lib,"libjpegd.lib")
#pragma comment(lib,"libpngd.lib")
#pragma comment(lib,"libtiffd.lib")
#pragma comment(lib,"zlibd.lib")




using namespace cv;
using namespace std;

//
//int main(int argc, char** argv)
//{
// 
//    cout<<"usage: test.exe infile outfile"<<endl;
//    Mat img = imread(argv[1]);
//    //imshow("before", img);
//    for (int x = 0; x != img.rows; x++)
//    {
//        
//        for (int y = 0; y != img.cols;y++)
//        {
//           img.at<Vec3b>(x, y)[2] = img.at<Vec3b>(x, y)[2] + 100;
//           
//
//            if(img.at<Vec3b>(x, y)[2] >255)
//                img.at<Vec3b>(x, y)[2]= 255;
//           
//        }
//    }
//    imwrite(argv[2], img);
//    //imshow("after", img);
//
//
//}


#include <opencv/cv.h>

#include <opencv/highgui.h>



using namespace cv;

using namespace std;





int main(int argc, char ** argv)

{

    // input args check

    if(argc < 3){

        printf("please input args.\n");

        printf("e.g. : ./test infilepath outfilepath \n");

        return 0;

    }



    char * input = argv[1];

    char * output = argv[2];



    printf("input: %s, output: %s\n", input, output);



    Mat src = imread(input, 1);



    int width=src.cols;

    int heigh=src.rows;

    RNG rng;

    Mat img(src.size(),CV_8UC3);

    for (int y=0; y<heigh; y++)

    {

        uchar* P0 = src.ptr<uchar>(y);

        uchar* P1 = img.ptr<uchar>(y);

        for (int x=0; x<width; x++)

        {

            float B=P0[3*x];

            float G=P0[3*x+1];

            float R=P0[3*x+2];

            float newB=0.272*R+0.534*G+0.131*B;

            float newG=0.349*R+0.686*G+0.168*B;

            float newR=0.393*R+0.769*G+0.189*B;

            if(newB<0)newB=0;

            if(newB>255)newB=255;

            if(newG<0)newG=0;

            if(newG>255)newG=255;

            if(newR<0)newR=0;

            if(newR>255)newR=255;

            P1[3*x] = (uchar)newB;

            P1[3*x+1] = (uchar)newG;

            P1[3*x+2] = (uchar)newR;

        }



    }

    //imshow("out",img);

    //waitKey();

    imwrite(output,img);

} 
