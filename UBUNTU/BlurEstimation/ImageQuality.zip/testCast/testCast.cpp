#include <core/core.hpp>
#include <highgui/highgui.hpp>
#include <vector>
#include <iostream>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <Windows.h>

#pragma comment(lib,"opencv_calib3d244d.lib")
#pragma comment(lib,"opencv_contrib244d.lib")
#pragma comment(lib,"opencv_core244d.lib")
#pragma comment(lib,"opencv_features2d244d.lib")
#pragma comment(lib,"opencv_flann244d.lib")
#pragma comment(lib,"opencv_gpu244d.lib")
//#pragma comment(lib,"opencv_haartraining_engine.lib")
#pragma comment(lib,"opencv_highgui244d.lib")
#pragma comment(lib,"opencv_imgproc244d.lib")
#pragma comment(lib,"opencv_legacy244d.lib")
#pragma comment(lib,"opencv_ml244d.lib")
#pragma comment(lib,"opencv_nonfree244d.lib")
#pragma comment(lib,"opencv_objdetect244d.lib")
#pragma comment(lib,"opencv_photo244d.lib")
#pragma comment(lib,"opencv_stitching244d.lib")
#pragma comment(lib,"opencv_ts244d.lib")
#pragma comment(lib,"opencv_video244d.lib")
#pragma comment(lib,"opencv_videostab244d.lib")


#pragma comment(lib,"IlmImfd.lib")
#pragma comment(lib,"libjasperd.lib")
#pragma comment(lib,"libjpegd.lib")
#pragma comment(lib,"libpngd.lib")
#pragma comment(lib,"libtiffd.lib")
#pragma comment(lib,"zlibd.lib")




using namespace cv;
using namespace std;






int main(int argc, char ** argv)
{

    // input args check

    if(argc < 3){

        printf("please input args.\n");

        printf("e.g. : ./test infilepath outfilepath \n");

        return 0;

    }



    char * input = argv[1];

    char * output = argv[2];



    printf("input: %s, output: %s\n", input, output);


    char srcPath[MAX_PATH];
    char dstPath[MAX_PATH];
    int index = 1;
    do 
    {
        sprintf(srcPath, "%s\\%04d.bmp", input, index);
        sprintf(dstPath, "%s\\%04d.bmp", output, index);
        index++;

        Mat roiImg;
        Mat src = imread(srcPath, 1);
        if(src.cols<10)
            return 0;
        Rect rect(0, 25, 720, 510);  
        src(rect).copyTo(roiImg);
        imwrite(dstPath,roiImg);


    } while (1);
   
    return 1;

} 
